import { useState, useEffect } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { User, CheckCircle, XCircle, Mail, ExternalLink, Clock } from 'lucide-react';
import { AdvisorApplication } from '../../data/mockData';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import { useToast } from '../ui/Toast';
import { User as UserType } from '../../utils/userStoreProduction';

interface AdminApplicationsProps {
  currentUser: UserType;
}

interface EmailModalProps {
  application: AdvisorApplication;
  onClose: () => void;
  onSend: (subject: string, body: string) => void;
}

function EmailModal({ application, onClose, onSend }: EmailModalProps) {
  const [subject, setSubject] = useState(
    `Your Ethiq Board Account Has Been Approved`
  );
  
  // Generate a temporary password for the new account
  const [tempPassword] = useState(() => {
    // Generate a secure temporary password
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%';
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  });

  const defaultBody = `Hello ${application.name},

Ethiq Board is designed to support high-quality advisory work by bringing clarity, structure, and professionalism to advisory relationships—so expectations, engagement, and outcomes stay easy to understand and easy to act on.

You can complete your account setup here:

Login URL: [Your login page URL]
Email: ${application.email}
Temporary Password: ${tempPassword}

IMPORTANT: Please change your password immediately after logging in for the first time. You can do this by going to your account settings.

Once your profile is complete, you'll be able to:

- Maintain a clear, professional advisory profile
- Engage with companies using structured advisory workflows
- Receive invitations when companies want to add you to their advisory board in Ethiq Board

Best regards,
The Ethiq Board Team`;

  const [body, setBody] = useState(defaultBody);

  const handleSend = () => {
    if (!body.trim()) {
      alert('Please enter an email body');
      return;
    }
    onSend(subject, body);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-6 z-50">
      <Card className="max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-gray-900 mb-1">Send Approval Email</h2>
            <p className="text-gray-600">To: {application.email}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-600 hover:text-gray-900 transition-colors"
          >
            <XCircle className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-gray-700 mb-2">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-gray-700 mb-2">
              Email Body <span className="text-red-500">*</span>
            </label>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent"
              rows={12}
              placeholder="Enter the approval email content here..."
            />
            <p className="text-gray-500 text-sm mt-1">
              This email will be sent to {application.name} to notify them of their approval.
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-blue-900 text-sm">
              <strong>Note:</strong> After clicking "Send Email", you'll need to manually send this
              email content to the applicant. The system will log the email for your reference.
            </p>
          </div>

          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <Button onClick={handleSend} className="flex-1">
              <Mail className="w-4 h-4 mr-2" />
              Send Email
            </Button>
            <Button variant="secondary" onClick={onClose} className="flex-1">
              Cancel
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

export function AdminApplications({ currentUser }: AdminApplicationsProps) {
  const [applications, setApplications] = useState<AdvisorApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<'All' | 'Pending' | 'Approved' | 'Denied'>('Pending');
  const [selectedApplication, setSelectedApplication] = useState<AdvisorApplication | null>(null);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const { showToast, ToastComponent } = useToast();

  useEffect(() => {
    loadApplications();
  }, []);

  const loadApplications = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0b8dc1d2/advisor-applications`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to load applications');
      }

      setApplications(data.applications);
    } catch (error) {
      console.error('Error loading applications:', error);
      showToast('Failed to load applications', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = (application: AdvisorApplication) => {
    setSelectedApplication(application);
    setShowEmailModal(true);
  };

  const handleSendApprovalEmail = async (subject: string, body: string) => {
    if (!selectedApplication) return;

    try {
      // Update application status
      const updateResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0b8dc1d2/advisor-applications/${selectedApplication.id}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            status: 'Approved',
            reviewed_by: currentUser.id,
          }),
        }
      );

      const updateData = await updateResponse.json();

      if (!updateData.success) {
        throw new Error(updateData.error || 'Failed to approve application');
      }

      // Log the email (in production, this would send via email service)
      console.log('\n📧 ============ APPROVAL EMAIL ============');
      console.log('To:', selectedApplication.email);
      console.log('Subject:', subject);
      console.log('Body:\n', body);
      console.log('==========================================\n');

      showToast('Application approved! Email logged to console.');
      setShowEmailModal(false);
      setSelectedApplication(null);
      loadApplications();
    } catch (error) {
      console.error('Error approving application:', error);
      showToast('Failed to approve application', 'error');
    }
  };

  const handleDeny = async (applicationId: string) => {
    if (!confirm('Are you sure you want to deny this application?')) {
      return;
    }

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-0b8dc1d2/advisor-applications/${applicationId}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            status: 'Denied',
            reviewed_by: currentUser.id,
          }),
        }
      );

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to deny application');
      }

      showToast('Application denied');
      loadApplications();
    } catch (error) {
      console.error('Error denying application:', error);
      showToast('Failed to deny application', 'error');
    }
  };

  const filteredApplications = applications.filter((app) => {
    if (filterStatus === 'All') return true;
    return app.status === filterStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'Approved':
        return 'bg-green-100 text-green-700';
      case 'Denied':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-600">Loading applications...</p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Advisor Applications</h1>
        <p className="text-gray-600">Review and manage advisor applications</p>
      </div>

      {/* Filter Tabs */}
      <div className="mb-6 flex gap-2">
        {(['All', 'Pending', 'Approved', 'Denied'] as const).map((status) => {
          const count = status === 'All' 
            ? applications.length 
            : applications.filter((a) => a.status === status).length;
          
          return (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filterStatus === status
                  ? 'bg-[#163BB5] text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              {status} ({count})
            </button>
          );
        })}
      </div>

      {/* Applications Table */}
      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Applicant</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Executive Type</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Experience</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Interests</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Status</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Submitted</th>
              <th className="px-6 py-3 text-right text-gray-700 text-sm">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredApplications.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-600">
                  No {filterStatus !== 'All' ? filterStatus.toLowerCase() : ''} applications found
                </td>
              </tr>
            ) : (
              filteredApplications.map((application) => (
                <tr key={application.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="text-gray-900">{application.name}</p>
                        <p className="text-gray-600 text-sm">{application.email}</p>
                        {application.linkedin_url && (
                          <a
                            href={application.linkedin_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#163BB5] text-sm flex items-center gap-1 hover:underline"
                          >
                            LinkedIn <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-md text-xs">
                      {application.executive_type}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs">
                      {application.years_experience}+ years
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {application.interests.slice(0, 2).map((interest) => (
                        <span
                          key={interest}
                          className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs"
                        >
                          {interest}
                        </span>
                      ))}
                      {application.interests.length > 2 && (
                        <span className="px-2 py-1 text-gray-600 text-xs">
                          +{application.interests.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-md text-xs ${getStatusColor(application.status)}`}>
                      {application.status}
                    </span>
                    {application.profile_visibility && (
                      <span className="ml-2 px-2 py-1 bg-purple-100 text-purple-700 rounded-md text-xs">
                        Visible
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-gray-600 text-sm">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {new Date(application.created_at).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-end gap-2">
                      {application.status === 'Pending' && (
                        <>
                          <Button
                            size="sm"
                            onClick={() => handleApprove(application)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => handleDeny(application.id)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <XCircle className="w-4 h-4 mr-1" />
                            Deny
                          </Button>
                        </>
                      )}
                      {application.status !== 'Pending' && (
                        <span className="text-gray-500 text-sm">
                          {application.status === 'Approved' ? 'Approved' : 'Denied'} on{' '}
                          {application.reviewed_at
                            ? new Date(application.reviewed_at).toLocaleDateString()
                            : 'N/A'}
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Email Modal */}
      {showEmailModal && selectedApplication && (
        <EmailModal
          application={selectedApplication}
          onClose={() => {
            setShowEmailModal(false);
            setSelectedApplication(null);
          }}
          onSend={handleSendApprovalEmail}
        />
      )}

      <ToastComponent />
    </div>
  );
}
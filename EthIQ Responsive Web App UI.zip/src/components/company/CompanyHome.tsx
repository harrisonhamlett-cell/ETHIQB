import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Send, Clock, CheckCircle2, AlertCircle } from 'lucide-react';
import { Nudge } from '../../data/mockData';

interface CompanyHomeProps {
  nudges: Nudge[];
  onNavigate: (page: string) => void;
}

export function CompanyHome({ nudges, onNavigate }: CompanyHomeProps) {
  const sentCount = nudges.filter((n) => n.status === 'Sent').length;
  const acceptedCount = nudges.filter((n) => n.status === 'Accepted').length;
  const awaitingCount = nudges.filter(
    (n) => n.advisor_completed && !n.company_confirmed
  ).length;
  
  // Completed this month
  const completedThisMonth = nudges.filter((n) => {
    if (n.status !== 'Completed') return false;
    const updatedDate = new Date(n.updated_at);
    const now = new Date();
    return (
      updatedDate.getMonth() === now.getMonth() &&
      updatedDate.getFullYear() === now.getFullYear()
    );
  }).length;

  const stats = [
    {
      label: 'Sent',
      value: sentCount,
      icon: Clock,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
    },
    {
      label: 'Accepted',
      value: acceptedCount,
      icon: CheckCircle2,
      color: 'text-purple-600',
      bg: 'bg-purple-50',
    },
    {
      label: 'Awaiting confirmation',
      value: awaitingCount,
      icon: AlertCircle,
      color: 'text-orange-600',
      bg: 'bg-orange-50',
    },
    {
      label: 'Completed this month',
      value: completedThisMonth,
      icon: CheckCircle2,
      color: 'text-green-600',
      bg: 'bg-green-50',
    },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Manage your advisor engagement</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-600 mb-2">{stat.label}</p>
                  <p className="text-gray-900">{stat.value}</p>
                </div>
                <div className={`${stat.bg} ${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Quick actions */}
      <div className="mt-12">
        <h2 className="text-gray-900 mb-6">Quick actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => onNavigate('relationships')}
            className="bg-white border border-gray-200 rounded-lg p-6 text-left hover:border-gray-300 transition-colors"
          >
            <h3 className="text-gray-900 mb-2">Advisors</h3>
            <p className="text-gray-600">Manage your connected advisors</p>
          </button>
          <button
            onClick={() => onNavigate('directory')}
            className="bg-white border border-gray-200 rounded-lg p-6 text-left hover:border-gray-300 transition-colors"
          >
            <h3 className="text-gray-900 mb-2">Directory</h3>
            <p className="text-gray-600">Discover new advisors</p>
          </button>
          <button
            onClick={() => onNavigate('handshakes')}
            className="bg-white border border-gray-200 rounded-lg p-6 text-left hover:border-gray-300 transition-colors"
          >
            <h3 className="text-gray-900 mb-2">Handshakes</h3>
            <p className="text-gray-600">View agreements and proposals</p>
          </button>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { Tabs } from '../ui/Tabs';
import { EmptyState } from '../ui/EmptyState';
import { Inbox, CheckCircle2, User } from 'lucide-react';
import { Nudge, mockAdvisors } from '../../data/mockData';

interface CompanyNudgesProps {
  nudges: Nudge[];
  onConfirmComplete: (nudgeId: string) => void;
}

export function CompanyNudges({ nudges, onConfirmComplete }: CompanyNudgesProps) {
  const [activeTab, setActiveTab] = useState(0);

  const sentNudges = nudges.filter((n) => n.status === 'Sent');
  const acceptedNudges = nudges.filter((n) => n.status === 'Accepted' && !n.advisor_completed);
  const declinedNudges = nudges.filter((n) => n.status === 'Declined');
  const awaitingNudges = nudges.filter((n) => n.advisor_completed && !n.company_confirmed);
  const completedNudges = nudges.filter((n) => n.status === 'Completed');

  const tabs = [
    { label: 'Sent', count: sentNudges.length },
    { label: 'Accepted', count: acceptedNudges.length },
    { label: 'Declined', count: declinedNudges.length },
    { label: 'Awaiting confirmation', count: awaitingNudges.length },
    { label: 'Completed', count: completedNudges.length },
  ];

  const getAdvisorById = (id: string) => mockAdvisors.find((a) => a.id === id);

  const renderNudgeList = (nudgeList: Nudge[], showConfirmButton = false, isCompleted = false) => {
    if (nudgeList.length === 0) {
      return (
        <EmptyState
          icon={<Inbox className="w-12 h-12" />}
          title="No nudges here"
          description="Nudges matching this status will appear here."
        />
      );
    }

    return (
      <div className="space-y-4">
        {nudgeList.map((nudge) => {
          const advisor = getAdvisorById(nudge.advisor_id);
          const date = new Date(nudge.updated_at).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          });

          return (
            <Card key={nudge.id}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                      <User className="w-4 h-4 text-gray-600" />
                    </div>
                    <div>
                      <h3 className="text-gray-900">{advisor?.name}</h3>
                      <p className="text-gray-600">{advisor?.title}</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <StatusBadge status={nudge.status} />
                </div>
              </div>

              <h3 className="text-gray-900 mb-2">{nudge.details}</h3>
              <p className="text-gray-600 mb-4 line-clamp-2">{nudge.nudge_tag} · {nudge.max_time_requested}</p>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-gray-600">
                  <span>Updated {date}</span>
                </div>

                {showConfirmButton && (
                  <Button onClick={() => onConfirmComplete(nudge.id)} size="sm">
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Confirm complete
                  </Button>
                )}
              </div>

              {isCompleted && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="flex gap-6 text-gray-600">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      <span>Advisor completed</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      <span>Company confirmed</span>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    );
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 0:
        return renderNudgeList(sentNudges);
      case 1:
        return renderNudgeList(acceptedNudges);
      case 2:
        return renderNudgeList(declinedNudges);
      case 3:
        return renderNudgeList(awaitingNudges, true);
      case 4:
        return renderNudgeList(completedNudges, false, true);
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Nudges</h1>
        <p className="text-gray-600">Track and manage your advisor requests</p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <p className="text-blue-900">
          <strong>Completion workflow:</strong> When an advisor marks a nudge as complete, it will
          appear in "Awaiting confirmation." You must confirm completion to finalize the nudge.
          Completed requires both you and the advisor to acknowledge completion.
        </p>
      </div>

      <Card>
        <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />
        <div className="mt-6">{renderTabContent()}</div>
      </Card>
    </div>
  );
}
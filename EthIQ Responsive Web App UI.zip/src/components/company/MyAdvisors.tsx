import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Search, Send, User, Calendar, Zap, Handshake as HandshakeIcon } from 'lucide-react';
import { mockAdvisors, Advisor, Relationship, Handshake, fixedInterests } from '../../data/mockData';

interface MyAdvisorsProps {
  relationships: Relationship[];
  handshakes: Handshake[];
  onSendNudge: (advisor: Advisor) => void;
  onProposeHandshake: (advisor: Advisor) => void;
  onInviteAdvisor: () => void;
}

export function MyAdvisors({ relationships, handshakes, onSendNudge, onProposeHandshake, onInviteAdvisor }: MyAdvisorsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'default' | 'nudges-asc'>('default');
  const [filterByInterest, setFilterByInterest] = useState<string>('');
  const [showPending, setShowPending] = useState(true);

  // Get advisors that have relationships with this company
  const connectedAdvisors = relationships
    .map((rel) => {
      const advisor = mockAdvisors.find((a) => a.id === rel.advisor_id);
      return advisor ? { advisor, relationship: rel } : null;
    })
    .filter((item): item is { advisor: Advisor; relationship: Relationship } => item !== null);

  let filteredAdvisors = connectedAdvisors.filter(({ advisor, relationship }) => {
    const matchesSearch =
      searchTerm === '' ||
      advisor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      advisor.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
      advisor.email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesInterest =
      filterByInterest === '' ||
      advisor.interests.some(interest => interest.includes(filterByInterest));

    const matchesStatus = showPending || relationship.status === 'active';

    return matchesSearch && matchesInterest && matchesStatus;
  });

  // Sort
  if (sortBy === 'nudges-asc') {
    filteredAdvisors = [...filteredAdvisors].sort(
      (a, b) => a.relationship.interaction_count - b.relationship.interaction_count
    );
  }

  const getRelationshipDuration = (connectedAt: string) => {
    const connected = new Date(connectedAt);
    const now = new Date();
    const months = Math.floor(
      (now.getTime() - connected.getTime()) / (1000 * 60 * 60 * 24 * 30)
    );
    if (months < 1) return 'Connected recently';
    if (months === 1) return 'Connected 1 month ago';
    return `Connected ${months} months ago`;
  };

  return (
    <div>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-gray-900 mb-2">My Advisors</h1>
          <p className="text-gray-600">Manage your advisor relationships</p>
        </div>
        <Button onClick={onInviteAdvisor}>
          <Send className="w-4 h-4 mr-2" />
          Invite Advisor
        </Button>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        {/* Search */}
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, role, or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
            />
          </div>
        </div>

        {/* Sort and filter */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-gray-700 mb-2">Sort by</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'default' | 'nudges-asc')}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
            >
              <option value="default">Default</option>
              <option value="nudges-asc">Least to most nudges sent</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 mb-2">Filter by type of help</label>
            <select
              value={filterByInterest}
              onChange={(e) => setFilterByInterest(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
            >
              <option value="">All interests</option>
              {fixedInterests.map((interest) => (
                <option key={interest} value={interest}>
                  {interest}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Show pending toggle */}
        <label className="flex items-center gap-2 text-gray-700 cursor-pointer">
          <input
            type="checkbox"
            checked={showPending}
            onChange={(e) => setShowPending(e.target.checked)}
            className="rounded border-gray-300"
          />
          Show pending invitations
        </label>
      </Card>

      {/* Results count */}
      <p className="text-gray-600 mb-4">
        {filteredAdvisors.length} advisor{filteredAdvisors.length !== 1 ? 's' : ''}
      </p>

      {/* Advisor grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAdvisors.map(({ advisor, relationship }) => {
          // Check if there's an active handshake for this advisor
          const activeHandshake = handshakes.find(
            (h) => h.advisor_id === advisor.id && h.status === 'Active'
          );
          const hasActiveHandshake = !!activeHandshake;

          return (
          <Card key={advisor.id} className="flex flex-col">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                <User className="w-6 h-6 text-gray-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-gray-900 mb-1">{advisor.name}</h3>
                <p className="text-gray-600">{advisor.role}</p>
                {relationship.status === 'pending' && (
                  <span className="inline-block mt-1 px-2 py-0.5 bg-orange-100 text-orange-700 rounded-md">
                    Pending
                  </span>
                )}
              </div>
            </div>

            {/* Interests */}
            <div className="mb-4">
              <p className="text-gray-700 mb-1">Interests:</p>
              <div className="flex flex-wrap gap-1.5">
                {advisor.interests.map((interest) => (
                  <span key={interest} className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-sm">
                    {interest}
                  </span>
                ))}
              </div>
            </div>

            {advisor.bio && <p className="text-gray-600 mb-4 flex-1">{advisor.bio}</p>}

            {/* Relationship metadata */}
            <div className="border-t border-gray-200 pt-4 mb-4">
              <div className="space-y-2 text-gray-600">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>{getRelationshipDuration(relationship.connected_at)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  <span>{relationship.interaction_count} nudge{relationship.interaction_count !== 1 ? 's' : ''}</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              {hasActiveHandshake ? (
                <Button
                  onClick={() => onSendNudge(advisor)}
                  className="flex-1"
                  disabled={relationship.status === 'pending'}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Nudge
                </Button>
              ) : (
                <Button
                  onClick={() => onProposeHandshake(advisor)}
                  className="flex-1"
                  disabled={relationship.status === 'pending'}
                >
                  <HandshakeIcon className="w-4 h-4 mr-2" />
                  Handshake
                </Button>
              )}
            </div>
          </Card>
          );
        })}
      </div>
    </div>
  );
}
import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Search, Send, User, MoreVertical, Mail } from 'lucide-react';
import {
  mockAdvisors,
  Advisor,
  Contact,
  fixedInterests,
  specialDomainsOptions,
  backgroundOptions,
} from '../../data/mockData';
import { StatusBadge } from '../ui/StatusBadge';
import { MultiSelectDropdown } from '../ui/MultiSelectDropdown';

interface DirectoryProps {
  companyName: string; // NEW: Current company name
  knocks: Contact[];
  onSendKnock: (advisor: Advisor) => void;
  onViewProfile: (advisor: Advisor) => void;
}

export function Directory({ companyName, knocks, onSendKnock, onViewProfile }: DirectoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [executiveTypeFilters, setExecutiveTypeFilters] = useState<string[]>([]);
  const [helpRequestedFilters, setHelpRequestedFilters] = useState<string[]>([]);
  const [experienceLevelFilter, setExperienceLevelFilter] = useState('');
  const [specialDomainsFilters, setSpecialDomainsFilters] = useState<string[]>([]);
  const [backgroundFilters, setBackgroundFilters] = useState<string[]>([]);
  const [showMoreFilters, setShowMoreFilters] = useState(false);

  // ACCESS CONTROL: Only show advisors who DON'T have this company in their relationships
  // (i.e., advisors available for initial contact)
  const availableAdvisors = mockAdvisors.filter((advisor) => {
    const isOpenToNewBoards = advisor.open_to_new_advisory_boards;
    const hasExistingRelationship = advisor.company_relationships?.includes(companyName);
    
    // Show advisors who are open to new boards AND don't already have a relationship with this company
    return isOpenToNewBoards && !hasExistingRelationship;
  });

  // Get knock status for an advisor
  const getKnockStatus = (advisorId: string) => {
    const knock = knocks.find((k) => k.advisor_id === advisorId);
    return knock?.status;
  };

  // Filter advisors
  let filteredAdvisors = availableAdvisors.filter((advisor) => {
    const matchesSearch =
      searchTerm === '' ||
      advisor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      advisor.role.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesExecutiveType =
      executiveTypeFilters.length === 0 ||
      executiveTypeFilters.includes(advisor.executive_type);

    const matchesHelpRequested =
      helpRequestedFilters.length === 0 ||
      helpRequestedFilters.some((filter) => advisor.interests.includes(filter));

    const matchesExperienceLevel =
      experienceLevelFilter === '' ||
      (experienceLevelFilter === '0-5' && advisor.years_experience <= 5) ||
      (experienceLevelFilter === '6-10' &&
        advisor.years_experience >= 6 &&
        advisor.years_experience <= 10) ||
      (experienceLevelFilter === '11-15' &&
        advisor.years_experience >= 11 &&
        advisor.years_experience <= 15) ||
      (experienceLevelFilter === '16+' && advisor.years_experience >= 16);

    const matchesSpecialDomains =
      specialDomainsFilters.length === 0 ||
      specialDomainsFilters.some((filter) => advisor.special_domains.includes(filter));

    const matchesBackground =
      backgroundFilters.length === 0 ||
      backgroundFilters.some((filter) => advisor.special_domains.includes(filter));

    return (
      matchesSearch &&
      matchesExecutiveType &&
      matchesHelpRequested &&
      matchesExperienceLevel &&
      matchesSpecialDomains &&
      matchesBackground
    );
  });

  const executiveTypes = [
    'Current Executive - Public Company',
    'Former Executive - Public Company',
    'Current Executive - Private Company',
    'Former Executive - Private Company',
    'Founder or CEO',
    'Consultant',
    'Venture Capitalist',
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Directory</h1>
        <p className="text-gray-600">Advisors open to new advisory boards</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-gradient-to-br from-[#F8F9FC] to-[#EEF0F8] border-2 border-[#163BB5]/20 rounded-xl p-6 mb-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-gray-900 mb-1">Filter Advisors</h2>
            <p className="text-gray-600 text-sm">Refine your search to find the right match</p>
          </div>
          {(executiveTypeFilters.length > 0 || 
            helpRequestedFilters.length > 0 || 
            experienceLevelFilter !== '' ||
            specialDomainsFilters.length > 0 ||
            backgroundFilters.length > 0) && (
            <button
              onClick={() => {
                setExecutiveTypeFilters([]);
                setHelpRequestedFilters([]);
                setExperienceLevelFilter('');
                setSpecialDomainsFilters([]);
                setBackgroundFilters([]);
              }}
              className="text-[#163BB5] hover:text-[#0D2A7A] transition-colors text-sm"
            >
              Clear all filters
            </button>
          )}
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search advisors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent bg-white shadow-sm"
            />
          </div>
        </div>

        {/* Filter row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <MultiSelectDropdown
            label="Executive Type"
            options={executiveTypes}
            selected={executiveTypeFilters}
            onChange={setExecutiveTypeFilters}
            placeholder="All types"
          />

          <MultiSelectDropdown
            label="Help Requested"
            options={fixedInterests}
            selected={helpRequestedFilters}
            onChange={setHelpRequestedFilters}
            placeholder="All interests"
          />

          <div>
            <label className="block text-gray-700 mb-2 uppercase text-xs">
              Experience Level
            </label>
            <select
              value={experienceLevelFilter}
              onChange={(e) => setExperienceLevelFilter(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
            >
              <option value="">All levels</option>
              <option value="0-5">0-5 years</option>
              <option value="6-10">6-10 years</option>
              <option value="11-15">11-15 years</option>
              <option value="16+">16+ years</option>
            </select>
          </div>
        </div>

        <div className="mb-4">
          <button
            onClick={() => setShowMoreFilters(!showMoreFilters)}
            className="w-full px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            {showMoreFilters ? 'Hide' : 'Show'} More Filters
          </button>
        </div>

        {/* More Filters Panel */}
        {showMoreFilters && (
          <div className="border-t border-gray-200 pt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <MultiSelectDropdown
              label="Special Domains"
              options={specialDomainsOptions}
              selected={specialDomainsFilters}
              onChange={setSpecialDomainsFilters}
              placeholder="All domains"
            />

            <MultiSelectDropdown
              label="Background"
              options={backgroundOptions}
              selected={backgroundFilters}
              onChange={setBackgroundFilters}
              placeholder="All backgrounds"
            />
          </div>
        )}
      </div>

      {/* Results count */}
      <p className="text-gray-600 mb-4">
        {filteredAdvisors.length} advisor{filteredAdvisors.length !== 1 ? 's' : ''}
      </p>

      {/* Table */}
      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200 sticky top-0">
            <tr>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Name</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Interests</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Executive Type</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Special Domains</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Experience</th>
              <th className="px-6 py-3 text-right text-gray-700 text-sm">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredAdvisors.map((advisor) => {
              const knockStatus = getKnockStatus(advisor.id);
              const canSendKnock = !knockStatus || knockStatus === 'Declined' || knockStatus === 'Expired';

              return (
                <tr key={advisor.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="text-gray-900">{advisor.name}</p>
                        <p className="text-gray-600 text-sm">{advisor.role}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {advisor.interests.slice(0, 2).map((interest) => (
                        <span
                          key={interest}
                          className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs truncate"
                        >
                          {interest.length > 20 ? `${interest.slice(0, 20)}...` : interest}
                        </span>
                      ))}
                      {advisor.interests.length > 2 && (
                        <span className="px-2 py-1 text-gray-600 text-xs">
                          +{advisor.interests.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-md text-xs">
                      {advisor.executive_type}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {advisor.special_domains.slice(0, 2).map((domain) => (
                        <span
                          key={domain}
                          className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs truncate"
                        >
                          {domain}
                        </span>
                      ))}
                      {advisor.special_domains.length > 2 && (
                        <span className="px-2 py-1 text-gray-600 text-xs">
                          +{advisor.special_domains.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs">
                      {advisor.years_experience}+ years
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col items-end gap-2">
                      {knockStatus ? (
                        <StatusBadge status={knockStatus} />
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => onSendKnock(advisor)}
                        >
                          <Mail className="w-4 h-4 mr-1" />
                          Contact
                        </Button>
                      )}
                      <Button size="sm" variant="secondary" onClick={() => onViewProfile(advisor)}>
                        View Profile
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {filteredAdvisors.length === 0 && (
        <Card className="text-center py-12">
          <p className="text-gray-900 mb-2">No advisors found</p>
          <p className="text-gray-600">Try adjusting your filters</p>
        </Card>
      )}
    </div>
  );
}
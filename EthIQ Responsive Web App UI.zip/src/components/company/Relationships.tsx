import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Search, User, MoreVertical, Send, Handshake as HandshakeIcon } from 'lucide-react';
import {
  mockAdvisors,
  Advisor,
  Relationship,
  Handshake,
  fixedInterests,
  specialDomainsOptions,
} from '../../data/mockData';

interface RelationshipsProps {
  relationships: Relationship[];
  handshakes: Handshake[];
  onViewProfile: (advisor: Advisor) => void;
  onSendNudge: (advisor: Advisor) => void;
  onProposeHandshake: (advisor: Advisor) => void;
  onBrowseDirectory: () => void;
}

export function Relationships({
  relationships,
  handshakes,
  onViewProfile,
  onSendNudge,
  onProposeHandshake,
  onBrowseDirectory,
}: RelationshipsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [executiveTypeFilters, setExecutiveTypeFilters] = useState<string[]>([]);
  const [helpRequestedFilters, setHelpRequestedFilters] = useState<string[]>([]);
  const [experienceLevelFilter, setExperienceLevelFilter] = useState('');
  const [specialDomainsFilters, setSpecialDomainsFilters] = useState<string[]>([]);
  const [showMoreFilters, setShowMoreFilters] = useState(false);

  // Get advisors with connected relationships
  const connectedAdvisors = relationships
    .filter((rel) => rel.status === 'connected')
    .map((rel) => {
      const advisor = mockAdvisors.find((a) => a.id === rel.advisor_id);
      return advisor ? { advisor, relationship: rel } : null;
    })
    .filter((item): item is { advisor: Advisor; relationship: Relationship } => item !== null);

  // Filter advisors
  let filteredAdvisors = connectedAdvisors.filter(({ advisor }) => {
    const matchesSearch =
      searchTerm === '' ||
      advisor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      advisor.role.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesExecutiveType =
      executiveTypeFilters.length === 0 || executiveTypeFilters.includes(advisor.executive_type);

    const matchesHelpRequested =
      helpRequestedFilters.length === 0 ||
      helpRequestedFilters.some((filter) => advisor.interests.includes(filter));

    const matchesExperienceLevel =
      experienceLevelFilter === '' ||
      (experienceLevelFilter === '0-5' && advisor.years_experience <= 5) ||
      (experienceLevelFilter === '6-10' &&
        advisor.years_experience >= 6 &&
        advisor.years_experience <= 10) ||
      (experienceLevelFilter === '11-15' &&
        advisor.years_experience >= 11 &&
        advisor.years_experience <= 15) ||
      (experienceLevelFilter === '16+' && advisor.years_experience >= 16);

    const matchesSpecialDomains =
      specialDomainsFilters.length === 0 ||
      specialDomainsFilters.some((filter) => advisor.special_domains.includes(filter));

    return (
      matchesSearch &&
      matchesExecutiveType &&
      matchesHelpRequested &&
      matchesExperienceLevel &&
      matchesSpecialDomains
    );
  });

  const toggleHelpRequested = (interest: string) => {
    setHelpRequestedFilters((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const toggleSpecialDomain = (domain: string) => {
    setSpecialDomainsFilters((prev) =>
      prev.includes(domain) ? prev.filter((d) => d !== domain) : [...prev, domain]
    );
  };

  const toggleExecutiveType = (type: string) => {
    setExecutiveTypeFilters((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  };

  const executiveTypes = [
    'Current Executive - Public Company',
    'Former Executive - Public Company',
    'Current Executive - Private Company',
    'Former Executive - Private Company',
    'Founder or CEO',
    'Consultant',
    'Venture Capitalist',
  ];

  if (connectedAdvisors.length === 0) {
    return (
      <div>
        <h1 className="text-gray-900 mb-8">Advisors</h1>
        <Card className="text-center py-12">
          <h2 className="text-gray-900 mb-2">No connected advisors yet</h2>
          <p className="text-gray-600 mb-6">Start building your advisor network</p>
          <Button onClick={onBrowseDirectory}>Browse Directory</Button>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Advisors</h1>
        <p className="text-gray-600">Manage your connected advisors</p>
      </div>

      {/* Search and Filters */}
      <Card className="mb-6">
        {/* Search */}
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search advisors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
            />
          </div>
        </div>

        {/* Filter dropdowns */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Executive Type */}
          <div>
            <label className="block text-gray-700 mb-2 text-sm">
              Executive Type
            </label>
            <select
              value={executiveTypeFilters[0] || ''}
              onChange={(e) => setExecutiveTypeFilters(e.target.value ? [e.target.value] : [])}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent text-sm"
            >
              <option value="">All types</option>
              {executiveTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Help Requested */}
          <div>
            <label className="block text-gray-700 mb-2 text-sm">
              Help Requested
            </label>
            <select
              value={helpRequestedFilters[0] || ''}
              onChange={(e) => setHelpRequestedFilters(e.target.value ? [e.target.value] : [])}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent text-sm"
            >
              <option value="">All interests</option>
              {fixedInterests.map((interest) => (
                <option key={interest} value={interest}>
                  {interest}
                </option>
              ))}
            </select>
          </div>

          {/* Experience Level */}
          <div>
            <label className="block text-gray-700 mb-2 text-sm">
              Experience Level
            </label>
            <select
              value={experienceLevelFilter}
              onChange={(e) => setExperienceLevelFilter(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent text-sm"
            >
              <option value="">All levels</option>
              <option value="0-5">0-5 years</option>
              <option value="6-10">6-10 years</option>
              <option value="11-15">11-15 years</option>
              <option value="16+">16+ years</option>
            </select>
          </div>
        </div>

        {/* More Filters toggle */}
        {showMoreFilters && (
          <div className="border-t border-gray-200 pt-4 mt-4">
            <label className="block text-gray-700 mb-2 text-sm">
              Special Domains
            </label>
            <select
              value={specialDomainsFilters[0] || ''}
              onChange={(e) => setSpecialDomainsFilters(e.target.value ? [e.target.value] : [])}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent text-sm"
            >
              <option value="">All domains</option>
              {specialDomainsOptions.map((domain) => (
                <option key={domain} value={domain}>
                  {domain}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* More Filters button */}
        <div className="mt-4">
          <button
            onClick={() => setShowMoreFilters(!showMoreFilters)}
            className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
          >
            {showMoreFilters ? 'Hide' : 'Show'} more filters
          </button>
        </div>
      </Card>

      {/* Results count */}
      <p className="text-gray-600 mb-4">
        {filteredAdvisors.length} advisor{filteredAdvisors.length !== 1 ? 's' : ''}
      </p>

      {/* Table */}
      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200 sticky top-0">
            <tr>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Name</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Interests</th>
              <th className="px-6 py-3 text-left text-gray-700 text-sm">Executive Type</th>
              <th className="px-6 py-3 text-right text-gray-700 text-sm">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredAdvisors.map(({ advisor, relationship }) => {
              // Check if there's an active handshake for this advisor
              const activeHandshake = handshakes.find(
                (h) => h.advisor_id === advisor.id && h.status === 'Active'
              );
              const hasActiveHandshake = !!activeHandshake;

              return (
                <tr key={advisor.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="text-gray-900">{advisor.name}</p>
                        <p className="text-gray-600 text-sm">{advisor.role}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {advisor.interests.slice(0, 2).map((interest) => (
                        <span
                          key={interest}
                          className="px-2 py-1 bg-gray-100 text-gray-700 rounded-md text-xs truncate"
                        >
                          {interest.length > 20 ? `${interest.slice(0, 20)}...` : interest}
                        </span>
                      ))}
                      {advisor.interests.length > 2 && (
                        <span className="px-2 py-1 text-gray-600 text-xs">
                          +{advisor.interests.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-md text-xs">
                      {advisor.executive_type}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      {hasActiveHandshake ? (
                        <Button size="sm" onClick={() => onSendNudge(advisor)}>
                          Nudge
                        </Button>
                      ) : (
                        <Button size="sm" onClick={() => onProposeHandshake(advisor)}>
                          <HandshakeIcon className="w-4 h-4 mr-1" />
                          Handshake
                        </Button>
                      )}
                      <Button size="sm" variant="secondary" onClick={() => onViewProfile(advisor)}>
                        View Profile
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {filteredAdvisors.length === 0 && (
        <Card className="text-center py-12">
          <p className="text-gray-900 mb-2">No advisors match your filters</p>
          <p className="text-gray-600">Try adjusting your search criteria</p>
        </Card>
      )}
    </div>
  );
}
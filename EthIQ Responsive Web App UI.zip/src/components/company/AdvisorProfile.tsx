import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { User, ArrowLeft } from 'lucide-react';
import { Advisor, Contact, Handshake, Relationship, Nudge } from '../../data/mockData';
import { StatusBadge } from '../ui/StatusBadge';

interface AdvisorProfileProps {
  advisor: Advisor;
  relationship: Relationship | null;
  knock: Contact | null;
  handshakes: Handshake[];
  nudges: Nudge[];
  onBack: () => void;
  onSendKnock: () => void;
  onProposeHandshake: () => void;
  onSendNudge: () => void;
}

export function AdvisorProfile({
  advisor,
  relationship,
  knock,
  handshakes,
  nudges,
  onBack,
  onSendKnock,
  onProposeHandshake,
  onSendNudge,
}: AdvisorProfileProps) {
  // Check handshake status
  const activeHandshake = handshakes.find((h) => h.status === 'Active');
  const proposedHandshake = handshakes.find((h) => h.status === 'Proposed');
  const isConnected = relationship?.status === 'connected';
  const knockAccepted = knock?.status === 'Accepted';

  // Filter nudges and handshakes for history
  const advisorNudges = nudges.filter((n) => n.advisor_id === advisor.id);
  const advisorHandshakes = handshakes.filter((h) => h.advisor_id === advisor.id);
  const advisorContacts = knock ? [knock] : [];

  return (
    <div>
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Back
      </button>

      {/* Header */}
      <Card className="mb-6">
        <div className="flex items-start gap-4">
          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
            <User className="w-10 h-10 text-gray-600" />
          </div>
          <div className="flex-1">
            <h1 className="text-gray-900 mb-2">{advisor.name}</h1>
            <p className="text-gray-600 mb-3">{advisor.role}</p>
            <div className="flex flex-wrap gap-2 mb-3">
              <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-md">
                {advisor.executive_type}
              </span>
              <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-md">
                {advisor.years_experience}+ years
              </span>
            </div>
            {advisor.bio && <p className="text-gray-600">{advisor.bio}</p>}
          </div>
        </div>

        {/* Interests */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="text-gray-700 mb-2">Interests</h3>
          <div className="flex flex-wrap gap-2">
            {advisor.interests.map((interest) => (
              <span key={interest} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-md">
                {interest}
              </span>
            ))}
          </div>
        </div>

        {/* Special Domains */}
        <div className="mt-4">
          <h3 className="text-gray-700 mb-2">Special Domains</h3>
          <div className="flex flex-wrap gap-2">
            {advisor.special_domains.map((domain) => (
              <span key={domain} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-md">
                {domain}
              </span>
            ))}
          </div>
        </div>
      </Card>

      {/* Relationship Context - State-based */}
      <Card className="mb-6">
        <h2 className="text-gray-900 mb-4">Relationship Context</h2>

        {/* State A: Not connected (Directory context) */}
        {!isConnected && !knockAccepted && (
          <div>
            {advisor.open_to_new_advisory_boards && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                <p className="text-green-900">
                  ✓ Open to new advisory boards
                </p>
              </div>
            )}

            {knock ? (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <StatusBadge status={knock.status} />
                  <p className="text-gray-600">
                    Sent {new Date(knock.created_at).toLocaleDateString()}
                  </p>
                </div>
                {knock.status === 'Sent' && (
                  <p className="text-gray-600">
                    Waiting for advisor to respond to your contact
                  </p>
                )}
                {knock.status === 'Declined' && (
                  <p className="text-gray-600">
                    This advisor declined your contact request
                  </p>
                )}
                {knock.status === 'Expired' && (
                  <p className="text-gray-600">
                    This contact request expired without response
                  </p>
                )}
              </div>
            ) : (
              <Button onClick={onSendKnock}>Send Contact</Button>
            )}
          </div>
        )}

        {/* State B: Contact accepted but no handshake */}
        {knockAccepted && !proposedHandshake && !activeHandshake && (
          <div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
              <p className="text-green-900">
                <strong>Contact accepted</strong> – {new Date(knock.responded_at!).toLocaleDateString()}
              </p>
              <p className="text-green-700 mt-1">
                The advisor is interested in connecting. Propose a handshake to define your working relationship.
              </p>
            </div>
            <Button onClick={onProposeHandshake}>Propose Handshake</Button>
          </div>
        )}

        {/* State C: Handshake Proposed */}
        {proposedHandshake && (
          <div>
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-4">
              <div className="flex items-center gap-3 mb-2">
                <StatusBadge status="Proposed" />
                <p className="text-purple-900">
                  <strong>Handshake proposed</strong>
                </p>
              </div>
              <p className="text-purple-700">
                Waiting for advisor to accept your handshake proposal
              </p>
              <div className="mt-3 space-y-1 text-purple-900">
                <p>• Capacity: {proposedHandshake.capacity_hours_per_month} hours/month</p>
                <p>• Cadence: {proposedHandshake.engagement_style}</p>
                <p>• Response expectation: {proposedHandshake.response_expectation}</p>
              </div>
            </div>
            <p className="text-gray-600 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              ⚠️ Nudges are not available until the handshake is accepted
            </p>
          </div>
        )}

        {/* State D: Handshake Active */}
        {activeHandshake && (
          <div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
              <div className="flex items-center gap-3 mb-3">
                <StatusBadge status="Active" />
                <p className="text-green-900">
                  <strong>Active handshake</strong>
                </p>
              </div>
              <div className="space-y-2 text-green-900">
                <p><strong>Capacity:</strong> {activeHandshake.capacity_hours_per_month} hours/month</p>
                <p><strong>Response expectation:</strong> {activeHandshake.response_expectation}</p>
                <p><strong>Cadence:</strong> {activeHandshake.engagement_style}</p>
                <p><strong>Channels:</strong> {activeHandshake.channels.join(', ')}</p>
                {activeHandshake.focus_areas.length > 0 && (
                  <p><strong>Focus areas:</strong> {activeHandshake.focus_areas.join(', ')}</p>
                )}
              </div>
            </div>
            <Button onClick={onSendNudge}>Send Nudge</Button>
          </div>
        )}
      </Card>

      {/* History Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Contacts History */}
        <Card>
          <h3 className="text-gray-900 mb-4">Contacts History</h3>
          {advisorContacts.length > 0 ? (
            <div className="space-y-3">
              {advisorContacts.map((k) => (
                <div key={k.id} className="pb-3 border-b border-gray-200 last:border-0">
                  <div className="flex items-center gap-2 mb-1">
                    <StatusBadge status={k.status} />
                  </div>
                  <p className="text-gray-600">{new Date(k.created_at).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">No contacts sent</p>
          )}
        </Card>

        {/* Handshakes History */}
        <Card>
          <h3 className="text-gray-900 mb-4">Handshakes History</h3>
          {advisorHandshakes.length > 0 ? (
            <div className="space-y-3">
              {advisorHandshakes.map((h) => (
                <div key={h.id} className="pb-3 border-b border-gray-200 last:border-0">
                  <div className="flex items-center gap-2 mb-1">
                    <StatusBadge status={h.status} />
                  </div>
                  <p className="text-gray-900">{h.title || 'Untitled'}</p>
                  <p className="text-gray-600">{new Date(h.created_at).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">No handshakes yet</p>
          )}
        </Card>

        {/* Nudges History */}
        <Card>
          <h3 className="text-gray-900 mb-4">Nudges History</h3>
          {advisorNudges.length > 0 ? (
            <div className="space-y-3">
              {advisorNudges.map((n) => (
                <div key={n.id} className="pb-3 border-b border-gray-200 last:border-0">
                  <div className="flex items-center gap-2 mb-1">
                    <StatusBadge status={n.status} />
                  </div>
                  <p className="text-gray-900">{n.nudge_tag}</p>
                  <p className="text-gray-600">{new Date(n.created_at).toLocaleDateString()}</p>
                  {n.status === 'Completed' && (
                    <div className="mt-1 text-green-700 text-sm">
                      ✓ Advisor completed · ✓ Company confirmed
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">No nudges sent</p>
          )}
        </Card>
      </div>
    </div>
  );
}
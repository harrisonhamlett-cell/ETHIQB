import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { X } from 'lucide-react';

interface InviteAdvisorProps {
  onSubmit: (email: string, message: string) => void;
  onCancel: () => void;
}

export function InviteAdvisor({ onSubmit, onCancel }: InviteAdvisorProps) {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      onSubmit(email, message);
      setEmail('');
      setMessage('');
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Invite Advisor</h1>
        <p className="text-gray-600">Add a new advisor to your network</p>
      </div>

      <Card>
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="email" className="block text-gray-700 mb-2">
              Email address <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="advisor@company.com"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
              required
            />
            <p className="text-gray-600 mt-2">
              The advisor will receive an email invitation to join Ethiq and complete their profile.
            </p>
          </div>

          <div className="mb-6">
            <label htmlFor="message" className="block text-gray-700 mb-2">
              Personal message (optional)
            </label>
            <textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Add a personal note to your invitation..."
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent resize-none"
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <p className="text-blue-900">
              <strong>Note:</strong> Once invited, the advisor will appear in your advisor list with
              a "Pending" status. They can accept nudges only after completing their onboarding.
            </p>
          </div>

          <div className="flex gap-3">
            <Button type="submit">Send Invitation</Button>
            <Button type="button" variant="secondary" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
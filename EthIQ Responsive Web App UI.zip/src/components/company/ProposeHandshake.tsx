import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { X, User } from 'lucide-react';
import { Advisor, mockAdvisors, Relationship, Contact } from '../../data/mockData';

interface ProposeHandshakeProps {
  companyName: string; // NEW: Current company name
  selectedAdvisor: Advisor | null;
  relationships: Relationship[];
  knocks: Contact[];
  onSubmit: (
    advisor: Advisor,
    capacityHours: number,
    cadence: string,
    responseExpectation: string,
    channels: string[],
    focusAreas: string[],
    startDate: string,
    reviewDate: string,
    notes: string
  ) => void;
  onCancel: () => void;
}

export function ProposeHandshake({
  companyName,
  selectedAdvisor: initialAdvisor,
  relationships,
  knocks,
  onSubmit,
  onCancel,
}: ProposeHandshakeProps) {
  const [selectedAdvisor, setSelectedAdvisor] = useState<Advisor | null>(initialAdvisor);
  const [capacityHours, setCapacityHours] = useState('5');
  const [cadence, setCadence] = useState<'Ad hoc' | 'Weekly' | 'Biweekly' | 'Monthly'>('Ad hoc');
  const [responseExpectation, setResponseExpectation] = useState<'24h' | '48h' | '72h' | '1 week'>(
    '48h'
  );
  const [channels, setChannels] = useState<string[]>(['Email']);
  const [focusAreas, setFocusAreas] = useState<string[]>([]);
  const [customFocusArea, setCustomFocusArea] = useState('');
  const [startDate, setStartDate] = useState('');
  const [reviewDate, setReviewDate] = useState('');
  const [notes, setNotes] = useState('');

  // ACCESS CONTROL: Get available advisors who have this company in their relationships
  // AND have either a connected relationship or accepted contact
  const availableAdvisors = mockAdvisors.filter((advisor) => {
    const hasCompanyRelationship = advisor.company_relationships?.includes(companyName);
    const relationship = relationships.find((r) => r.advisor_id === advisor.id);
    const knock = knocks.find((k) => k.advisor_id === advisor.id && k.company_relationship === companyName);
    
    // Must have company relationship AND (connected OR contact accepted)
    return hasCompanyRelationship && (relationship?.status === 'connected' || knock?.status === 'Accepted');
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAdvisor && capacityHours && channels.length > 0) {
      onSubmit(
        selectedAdvisor,
        parseInt(capacityHours),
        cadence,
        responseExpectation,
        channels,
        focusAreas,
        startDate,
        reviewDate,
        notes
      );
    }
  };

  const toggleChannel = (channel: string) => {
    setChannels((prev) =>
      prev.includes(channel) ? prev.filter((c) => c !== channel) : [...prev, channel]
    );
  };

  const addFocusArea = () => {
    if (customFocusArea.trim() && !focusAreas.includes(customFocusArea.trim())) {
      setFocusAreas([...focusAreas, customFocusArea.trim()]);
      setCustomFocusArea('');
    }
  };

  const removeFocusArea = (area: string) => {
    setFocusAreas(focusAreas.filter((a) => a !== area));
  };

  return (
    <div className="max-w-2xl mx-auto">
      {/* Selected advisor */}
      {selectedAdvisor && (
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
                <User className="w-5 h-5 text-gray-600" />
              </div>
              <div>
                <p className="text-gray-600">Proposing handshake to</p>
                <h3 className="text-gray-900">{selectedAdvisor.name}</h3>
              </div>
            </div>
            <button
              onClick={onCancel}
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}

      {/* Form */}
      <Card>
        <h2 className="text-gray-900 mb-2">Propose Handshake</h2>
        <p className="text-gray-600 mb-6">
          Define the working relationship and expectations
        </p>

        <form onSubmit={handleSubmit}>
          {/* Advisor selector (if not locked) */}
          {!initialAdvisor && (
            <div className="mb-6">
              <label htmlFor="advisor" className="block text-gray-700 mb-2">
                Select Advisor *
              </label>
              <select
                id="advisor"
                value={selectedAdvisor?.id || ''}
                onChange={(e) => {
                  const advisor = availableAdvisors.find((a) => a.id === e.target.value);
                  setSelectedAdvisor(advisor || null);
                }}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
                required
              >
                <option value="">Choose an advisor</option>
                {availableAdvisors.map((advisor) => (
                  <option key={advisor.id} value={advisor.id}>
                    {advisor.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="mb-6">
            <label htmlFor="capacityHours" className="block text-gray-700 mb-2">
              Capacity hours/month *
            </label>
            <input
              type="number"
              id="capacityHours"
              value={capacityHours}
              onChange={(e) => setCapacityHours(e.target.value)}
              min="1"
              max="40"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
              required
            />
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 mb-3">
              Engagement cadence *
            </label>
            <div className="flex flex-wrap gap-2">
              {(['Ad hoc', 'Weekly', 'Biweekly', 'Monthly'] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setCadence(option)}
                  className={`px-4 py-2 rounded-full border transition-all ${
                    cadence === option
                      ? 'bg-gray-900 text-white border-gray-900'
                      : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 mb-3">
              Response expectation *
            </label>
            <div className="flex flex-wrap gap-2">
              {(['24h', '48h', '72h', '1 week'] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setResponseExpectation(option)}
                  className={`px-4 py-2 rounded-full border transition-all ${
                    responseExpectation === option
                      ? 'bg-gray-900 text-white border-gray-900'
                      : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 mb-3">
              Channels (select at least 1) *
            </label>
            <div className="flex flex-wrap gap-2">
              {['Email', 'Calendar', 'Slack', 'Phone'].map((channel) => (
                <button
                  key={channel}
                  type="button"
                  onClick={() => toggleChannel(channel)}
                  className={`px-4 py-2 rounded-full border transition-all ${
                    channels.includes(channel)
                      ? 'bg-gray-900 text-white border-gray-900'
                      : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {channel}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 mb-2">
              Focus areas (optional)
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={customFocusArea}
                onChange={(e) => setCustomFocusArea(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addFocusArea();
                  }
                }}
                placeholder="Add a focus area..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
              />
              <Button type="button" onClick={addFocusArea}>
                Add
              </Button>
            </div>
            {focusAreas.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {focusAreas.map((area) => (
                  <span
                    key={area}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full flex items-center gap-2"
                  >
                    {area}
                    <button
                      type="button"
                      onClick={() => removeFocusArea(area)}
                      className="text-gray-600 hover:text-gray-900"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label htmlFor="startDate" className="block text-gray-700 mb-2">
                Start date (optional)
              </label>
              <input
                type="date"
                id="startDate"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
              />
            </div>

            <div>
              <label htmlFor="reviewDate" className="block text-gray-700 mb-2">
                Review date (optional)
              </label>
              <input
                type="date"
                id="reviewDate"
                value={reviewDate}
                onChange={(e) => setReviewDate(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
              />
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="notes" className="block text-gray-700 mb-2">
              Notes (optional)
            </label>
            <textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-gray-50"
            />
          </div>

          <button
            type="submit"
            disabled={!selectedAdvisor || !capacityHours || channels.length === 0}
            className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            Send Handshake Proposal
          </button>
        </form>
      </Card>
    </div>
  );
}
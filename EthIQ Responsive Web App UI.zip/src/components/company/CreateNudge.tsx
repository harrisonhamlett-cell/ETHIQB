import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { User, X } from 'lucide-react';
import { Advisor, Handshake, nudgeTags, maxTimeOptions } from '../../data/mockData';

interface CreateNudgeProps {
  companyName: string; // NEW: Current company name
  selectedAdvisor: Advisor | null;
  handshakes: Handshake[];
  onSubmit: (details: string, nudgeTag: string, maxTime: string, advisor: Advisor) => void;
  onCancel: () => void;
  onProposeHandshake?: () => void;
}

export function CreateNudge({ companyName, selectedAdvisor, handshakes, onSubmit, onCancel, onProposeHandshake }: CreateNudgeProps) {
  const [details, setDetails] = useState('');
  const [nudgeTag, setNudgeTag] = useState('');
  const [maxTime, setMaxTime] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAdvisor && details.trim() && nudgeTag && maxTime) {
      onSubmit(details, nudgeTag, maxTime, selectedAdvisor);
    }
  };

  if (!selectedAdvisor) {
    return (
      <div>
        <h1 className="text-gray-900 mb-4">Create Nudge</h1>
        <Card>
          <p className="text-gray-600">Please select an advisor first.</p>
        </Card>
      </div>
    );
  }

  // ACCESS CONTROL: Check if there's an Active handshake with this company
  const activeHandshake = handshakes.find(
    (h) => h.advisor_id === selectedAdvisor.id && 
           h.status === 'Active' && 
           h.company_relationship === companyName // MUST match current company
  );

  if (!activeHandshake) {
    return (
      <div className="max-w-2xl mx-auto">
        {/* Selected advisor */}
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
                <User className="w-5 h-5 text-gray-600" />
              </div>
              <div>
                <p className="text-gray-600">Sending to</p>
                <h3 className="text-gray-900">{selectedAdvisor.name}</h3>
              </div>
            </div>
            <button
              onClick={onCancel}
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </Card>

        <Card className="text-center py-12">
          <h2 className="text-gray-900 mb-2">Handshake Required</h2>
          <p className="text-gray-600 mb-6">
            You need an active handshake with {selectedAdvisor.name} before you can send nudges.
          </p>
          {onProposeHandshake && (
            <Button onClick={onProposeHandshake}>Propose Handshake</Button>
          )}
          <div className="mt-4">
            <Button variant="secondary" onClick={onCancel}>
              Go Back
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Selected advisor */}
      <Card className="mb-6 bg-blue-50 border-blue-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
              <User className="w-5 h-5 text-gray-600" />
            </div>
            <div>
              <p className="text-gray-600">Sending to</p>
              <h3 className="text-gray-900">{selectedAdvisor.name}</h3>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-gray-600 hover:text-gray-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </Card>

      {/* Form */}
      <Card>
        <h2 className="text-gray-900 mb-6">Send a Nudge</h2>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="details" className="block text-gray-700 mb-2">
              Add context or details for review *
            </label>
            <textarea
              id="details"
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="Provide detailed information about your request..."
              rows={6}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-gray-50"
              required
            />
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 mb-3">
              Nudge Type *
            </label>
            <div className="flex flex-wrap gap-2">
              {nudgeTags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setNudgeTag(tag)}
                  className={`px-4 py-2 rounded-full border transition-all ${
                    nudgeTag === tag
                      ? 'bg-gray-900 text-white border-gray-900'
                      : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 mb-3">
              Max time requested *
            </label>
            <div className="flex flex-wrap gap-2">
              {maxTimeOptions.map((time) => (
                <button
                  key={time}
                  type="button"
                  onClick={() => setMaxTime(time)}
                  className={`px-4 py-2 rounded-full border transition-all ${
                    maxTime === time
                      ? 'bg-gray-900 text-white border-gray-900'
                      : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {time}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={!details.trim() || !nudgeTag || !maxTime}
            className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            Submit
          </button>
        </form>
      </Card>
    </div>
  );
}
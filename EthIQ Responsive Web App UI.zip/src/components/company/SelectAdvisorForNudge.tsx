import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Search, User, ChevronRight } from 'lucide-react';
import { mockAdvisors, Advisor, Relationship } from '../../data/mockData';

interface SelectAdvisorForNudgeProps {
  relationships: Relationship[];
  onSelectAdvisor: (advisor: Advisor) => void;
  onCancel: () => void;
}

export function SelectAdvisorForNudge({
  relationships,
  onSelectAdvisor,
  onCancel,
}: SelectAdvisorForNudgeProps) {
  const [searchTerm, setSearchTerm] = useState('');

  // Get only active advisors
  const connectedAdvisors = relationships
    .filter((rel) => rel.status === 'active')
    .map((rel) => {
      const advisor = mockAdvisors.find((a) => a.id === rel.advisor_id);
      return advisor ? { advisor, relationship: rel } : null;
    })
    .filter((item): item is { advisor: Advisor; relationship: Relationship } => item !== null);

  const filteredAdvisors = connectedAdvisors.filter(({ advisor }) => {
    const matchesSearch =
      searchTerm === '' ||
      advisor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      advisor.role.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Send a Nudge</h1>
        <p className="text-gray-600">Choose an advisor to send your request</p>
      </div>

      <Card className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by name or role..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
          />
        </div>
      </Card>

      <p className="text-gray-600 mb-4">
        {filteredAdvisors.length} advisor{filteredAdvisors.length !== 1 ? 's' : ''} available
      </p>

      <div className="space-y-3 mb-6">
        {filteredAdvisors.map(({ advisor, relationship }) => (
          <Card
            key={advisor.id}
            className="cursor-pointer hover:border-gray-300 transition-all"
            onClick={() => onSelectAdvisor(advisor)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                  <User className="w-6 h-6 text-gray-600" />
                </div>
                <div>
                  <h3 className="text-gray-900 mb-1">{advisor.name}</h3>
                  <p className="text-gray-600">{advisor.role}</p>
                  <div className="flex gap-2 mt-1">
                    {advisor.interests.slice(0, 2).map((interest) => (
                      <span
                        key={interest}
                        className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded-md text-sm"
                      >
                        {interest}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          </Card>
        ))}
      </div>

      <Button variant="secondary" onClick={onCancel}>
        Cancel
      </Button>
    </div>
  );
}

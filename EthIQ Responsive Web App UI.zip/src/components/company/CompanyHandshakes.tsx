import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Handshake, mockAdvisors } from '../../data/mockData';
import { StatusBadge } from '../ui/StatusBadge';

interface CompanyHandshakesProps {
  handshakes: Handshake[];
  onProposeHandshake: () => void;
  onViewHandshake: (handshake: Handshake) => void;
}

export function CompanyHandshakes({
  handshakes,
  onProposeHandshake,
  onViewHandshake,
}: CompanyHandshakesProps) {
  const [activeTab, setActiveTab] = useState<'proposed' | 'active' | 'history'>('active');

  const proposedHandshakes = handshakes.filter((h) => h.status === 'Proposed');
  const activeHandshakes = handshakes.filter((h) => h.status === 'Active');
  const historyHandshakes = handshakes.filter(
    (h) => h.status === 'Dismissed' || h.status === 'Paused' || h.status === 'Ended'
  );

  const currentList =
    activeTab === 'proposed'
      ? proposedHandshakes
      : activeTab === 'active'
      ? activeHandshakes
      : historyHandshakes;

  const getAdvisorName = (advisorId: string) => {
    return mockAdvisors.find((a) => a.id === advisorId)?.name || 'Unknown';
  };

  return (
    <div>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-gray-900 mb-2">Handshakes</h1>
          <p className="text-gray-600">
            Handshakes define how you work together (capacity, cadence, and expectations)
          </p>
        </div>
        <Button onClick={onProposeHandshake}>Propose Handshake</Button>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('proposed')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'proposed'
                ? 'border-gray-900 text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Proposed ({proposedHandshakes.length})
          </button>
          <button
            onClick={() => setActiveTab('active')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'active'
                ? 'border-gray-900 text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Active ({activeHandshakes.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-gray-900 text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            History ({historyHandshakes.length})
          </button>
        </div>
      </div>

      {/* Table */}
      {currentList.length > 0 ? (
        <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-gray-700">Advisor</th>
                <th className="px-6 py-3 text-left text-gray-700">Status</th>
                <th className="px-6 py-3 text-left text-gray-700">Capacity</th>
                <th className="px-6 py-3 text-left text-gray-700">Response Expectation</th>
                <th className="px-6 py-3 text-left text-gray-700">Cadence</th>
                <th className="px-6 py-3 text-left text-gray-700">Last Updated</th>
                <th className="px-6 py-3 text-right text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {currentList.map((handshake) => {
                const date = new Date(handshake.updated_at).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                });

                return (
                  <tr key={handshake.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-gray-900">{getAdvisorName(handshake.advisor_id)}</p>
                        {handshake.title && (
                          <p className="text-gray-600">{handshake.title}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={handshake.status} />
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-900">{handshake.capacity_hours_per_month} hrs/mo</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-900">{handshake.response_expectation}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-900">{handshake.engagement_style}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-600">{date}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-end">
                        <Button size="sm" variant="secondary" onClick={() => onViewHandshake(handshake)}>
                          View
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <Card className="text-center py-12">
          <h2 className="text-gray-900 mb-2">
            No {activeTab} handshakes
          </h2>
          <p className="text-gray-600 mb-6">
            {activeTab === 'proposed'
              ? 'Propose a handshake to define working relationships with advisors'
              : activeTab === 'active'
              ? 'No active handshakes at this time'
              : 'No handshake history yet'}
          </p>
          {activeTab === 'proposed' && (
            <Button onClick={onProposeHandshake}>Propose Handshake</Button>
          )}
        </Card>
      )}
    </div>
  );
}

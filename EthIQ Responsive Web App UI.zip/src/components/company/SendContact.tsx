import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { User, X } from 'lucide-react';
import { Advisor } from '../../data/mockData';

interface SendContactProps {
  selectedAdvisor: Advisor | null;
  onSubmit: (message: string, advisor: Advisor, cadence: string, compensation: string) => void;
  onCancel: () => void;
}

const compensationOptions = [
  'Hourly Rate',
  'Common Stock',
  'Employee Stock',
  'RevShare Agreement',
  'Open to All',
  'Other',
];

export function SendContact({ selectedAdvisor, onSubmit, onCancel }: SendContactProps) {
  const [message, setMessage] = useState('');
  const [cadence, setCadence] = useState('');
  const [compensation, setCompensation] = useState('');
  const [errors, setErrors] = useState<{ message?: string; cadence?: string; compensation?: string }>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: { message?: string; cadence?: string; compensation?: string } = {};

    if (!message.trim()) {
      newErrors.message = 'Please enter a message';
    }

    if (!cadence.trim()) {
      newErrors.cadence = 'Please enter the suggested engagement cadence';
    }

    if (!compensation) {
      newErrors.compensation = 'Please select a compensation method';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    if (selectedAdvisor) {
      onSubmit(message, selectedAdvisor, cadence, compensation);
    }
  };

  if (!selectedAdvisor) {
    return (
      <div>
        <h1 className="text-gray-900 mb-4">Send Contact</h1>
        <Card>
          <p className="text-gray-600">Please select an advisor first.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Selected advisor */}
      <Card className="mb-6 bg-blue-50 border-blue-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
              <User className="w-5 h-5 text-gray-600" />
            </div>
            <div>
              <p className="text-gray-600">Sending contact to</p>
              <h3 className="text-gray-900">{selectedAdvisor.name}</h3>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-gray-600 hover:text-gray-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </Card>

      {/* Form */}
      <Card>
        <h2 className="text-gray-900 mb-2">Send Contact</h2>
        <p className="text-gray-600 mb-6">
          Introduce yourself and explain why you'd like to connect
        </p>

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="message" className="block text-gray-700 mb-2">
              Message *
            </label>
            <textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell the advisor why you're reaching out and what you're hoping to collaborate on..."
              rows={8}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-gray-50"
              required
            />
            {errors.message && <p className="text-red-500 text-sm mt-1">{errors.message}</p>}
          </div>

          <div className="mb-6">
            <label htmlFor="cadence" className="block text-gray-700 mb-2">
              Suggested Engagement Cadence *
            </label>
            <input
              type="text"
              id="cadence"
              value={cadence}
              onChange={(e) => setCadence(e.target.value)}
              placeholder="e.g., Weekly calls, monthly check-ins..."
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
              required
            />
            {errors.cadence && <p className="text-red-500 text-sm mt-1">{errors.cadence}</p>}
          </div>

          <div className="mb-6">
            <label htmlFor="compensation" className="block text-gray-700 mb-2">
              Compensation Method *
            </label>
            <select
              id="compensation"
              value={compensation}
              onChange={(e) => setCompensation(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
              required
            >
              <option value="">Select a compensation method</option>
              {compensationOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            {errors.compensation && <p className="text-red-500 text-sm mt-1">{errors.compensation}</p>}
          </div>

          <div className="flex gap-3">
            <button
              type="submit"
              disabled={!message.trim() || !cadence.trim() || !compensation}
              className="flex-1 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Send Contact
            </button>
            <Button type="button" variant="secondary" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}

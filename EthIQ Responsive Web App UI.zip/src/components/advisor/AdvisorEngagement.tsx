import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { 
  ArrowLeft, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  Users, 
  Calendar,
  Activity,
  Target
} from 'lucide-react';
import { Nudge, Handshake as HandshakeType, Contact } from '../../data/mockData';

interface AdvisorEngagementProps {
  nudges: Nudge[];
  handshakes: HandshakeType[];
  contacts: Contact[];
  onNavigate: (page: string) => void;
}

export function AdvisorEngagement({ 
  nudges, 
  handshakes, 
  contacts, 
  onNavigate 
}: AdvisorEngagementProps) {
  // Calculate engagement metrics
  const activeHandshakes = handshakes.filter((h) => h.status === 'Active');
  const completedNudges = nudges.filter((n) => n.status === 'Completed');
  const acceptedContacts = contacts.filter((c) => c.status === 'Accepted');
  const totalNudges = nudges.length;
  const completionRate = totalNudges > 0 
    ? Math.round((completedNudges.length / totalNudges) * 100) 
    : 0;

  // Calculate average response time (mock calculation)
  const avgResponseHours = 18; // In a real app, calculate from timestamps

  // Calculate total hours committed per month from active handshakes
  const totalMonthlyHours = activeHandshakes.reduce(
    (sum, h) => sum + h.capacity_hours_per_month, 
    0
  );

  // Get nudge type breakdown
  const nudgeTypeBreakdown = nudges.reduce((acc, nudge) => {
    acc[nudge.nudge_tag] = (acc[nudge.nudge_tag] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Get engagement style breakdown from handshakes
  const engagementStyles = activeHandshakes.reduce((acc, h) => {
    acc[h.engagement_style] = (acc[h.engagement_style] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Calculate activity trend (last 30 days)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const recentNudges = nudges.filter(
    (n) => new Date(n.created_at) >= thirtyDaysAgo
  );

  const stats = [
    {
      label: 'Active Handshakes',
      value: activeHandshakes.length,
      icon: Users,
      color: 'text-[#163BB5]',
      bg: 'bg-blue-50',
      description: 'Current active engagements',
    },
    {
      label: 'Completion Rate',
      value: `${completionRate}%`,
      icon: CheckCircle2,
      color: 'text-green-600',
      bg: 'bg-green-50',
      description: `${completedNudges.length} of ${totalNudges} nudges completed`,
    },
    {
      label: 'Avg Response Time',
      value: `${avgResponseHours}h`,
      icon: Clock,
      color: 'text-purple-600',
      bg: 'bg-purple-50',
      description: 'Average time to respond',
    },
    {
      label: 'Monthly Commitment',
      value: `${totalMonthlyHours}h`,
      icon: Calendar,
      color: 'text-orange-600',
      bg: 'bg-orange-50',
      description: 'Total hours committed per month',
    },
  ];

  return (
    <div>
      {/* Header with back button */}
      <div className="mb-8">
        <Button 
          variant="secondary" 
          onClick={() => onNavigate('home')}
          size="sm"
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>
        <h1 className="text-gray-900 mb-2">Engagement Analytics</h1>
        <p className="text-gray-600">Track your advisory activity and performance metrics</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <div className="flex items-start justify-between mb-3">
                <div className={`${stat.bg} ${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
              <p className="text-gray-600 mb-1 text-sm">{stat.label}</p>
              <p className="text-gray-900 mb-1">{stat.value}</p>
              <p className="text-gray-500 text-xs">{stat.description}</p>
            </Card>
          );
        })}
      </div>

      {/* Activity Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Recent Activity */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <Activity className="w-5 h-5 text-gray-700" />
            <h2 className="text-gray-900">Recent Activity (30 days)</h2>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-gray-200">
              <span className="text-gray-700">New nudges received</span>
              <span className="text-gray-900">{recentNudges.length}</span>
            </div>
            <div className="flex items-center justify-between py-3 border-b border-gray-200">
              <span className="text-gray-700">Nudges completed</span>
              <span className="text-gray-900">
                {recentNudges.filter((n) => n.status === 'Completed').length}
              </span>
            </div>
            <div className="flex items-center justify-between py-3 border-b border-gray-200">
              <span className="text-gray-700">New opportunities accepted</span>
              <span className="text-gray-900">{acceptedContacts.length}</span>
            </div>
            <div className="flex items-center justify-between py-3">
              <span className="text-gray-700">Active handshakes</span>
              <span className="text-gray-900">{activeHandshakes.length}</span>
            </div>
          </div>
        </Card>

        {/* Nudge Type Breakdown */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <Target className="w-5 h-5 text-gray-700" />
            <h2 className="text-gray-900">Nudge Type Breakdown</h2>
          </div>
          {Object.keys(nudgeTypeBreakdown).length > 0 ? (
            <div className="space-y-3">
              {Object.entries(nudgeTypeBreakdown)
                .sort(([, a], [, b]) => b - a)
                .map(([type, count]) => (
                  <div key={type}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-700 text-sm">{type}</span>
                      <span className="text-gray-900">{count}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-[#163BB5] h-2 rounded-full transition-all"
                        style={{
                          width: `${(count / totalNudges) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
            </div>
          ) : (
            <p className="text-gray-600">No nudge data available</p>
          )}
        </Card>
      </div>

      {/* Engagement Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Handshake Details */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-5 h-5 text-gray-700" />
            <h2 className="text-gray-900">Active Handshake Details</h2>
          </div>
          {activeHandshakes.length > 0 ? (
            <div className="space-y-4">
              {activeHandshakes.map((handshake) => (
                <div 
                  key={handshake.id} 
                  className="p-4 bg-gray-50 rounded-lg border border-gray-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-gray-900 mb-1">
                        {handshake.title || 'Advisory Engagement'}
                      </p>
                      <p className="text-gray-600 text-sm">{handshake.engagement_style}</p>
                    </div>
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                      Active
                    </span>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Hours/month:</span>
                      <span className="text-gray-900">{handshake.capacity_hours_per_month}h</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Response time:</span>
                      <span className="text-gray-900">{handshake.response_expectation}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Channels:</span>
                      <span className="text-gray-900">{handshake.channels.join(', ')}</span>
                    </div>
                  </div>
                  {handshake.focus_areas && handshake.focus_areas.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-300">
                      <p className="text-gray-600 text-xs mb-2">Focus Areas:</p>
                      <div className="flex flex-wrap gap-2">
                        {handshake.focus_areas.map((area) => (
                          <span 
                            key={area}
                            className="px-2 py-1 bg-white border border-gray-200 text-gray-700 text-xs rounded"
                          >
                            {area}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">No active handshakes</p>
          )}
        </Card>

        {/* Engagement Style Preferences */}
        <Card>
          <div className="flex items-center gap-3 mb-6">
            <Calendar className="w-5 h-5 text-gray-700" />
            <h2 className="text-gray-900">Engagement Styles</h2>
          </div>
          {Object.keys(engagementStyles).length > 0 ? (
            <div className="space-y-4">
              {Object.entries(engagementStyles).map(([style, count]) => (
                <div key={style} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-900">{style}</span>
                    <span className="text-gray-600">
                      {count} {count === 1 ? 'engagement' : 'engagements'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">No engagement data available</p>
          )}
          
          {/* Summary insight */}
          {activeHandshakes.length > 0 && (
            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-blue-900 text-sm">
                <strong>Insight:</strong> You're currently managing {activeHandshakes.length} active{' '}
                {activeHandshakes.length === 1 ? 'engagement' : 'engagements'} with a total commitment 
                of {totalMonthlyHours} hours per month.
              </p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Building2, Calendar, DollarSign, CheckCircle2, XCircle, Users, TrendingUp, Zap, Activity } from 'lucide-react';
import { Contact, mockCompanies, Advisor, mockHandshakes } from '../../data/mockData';
import { StatusBadge } from '../ui/StatusBadge';

interface AdvisorContactsProps {
  contacts: Contact[];
  advisor: Advisor;
  onAccept: (contactId: string) => void;
  onDecline: (contactId: string) => void;
}

export function AdvisorContacts({ contacts, advisor, onAccept, onDecline }: AdvisorContactsProps) {
  const [activeTab, setActiveTab] = useState<'new' | 'history'>('new');

  const newContacts = contacts.filter((k) => k.status === 'Sent');
  const historyContacts = contacts.filter(
    (k) => k.status === 'Accepted' || k.status === 'Declined' || k.status === 'Expired'
  );

  const currentList = activeTab === 'new' ? newContacts : historyContacts;

  // Calculate advisor's current commitments
  const activeHandshakes = mockHandshakes.filter(
    h => h.advisor_id === advisor.id && h.status === 'Active'
  );
  const totalCommitments = activeHandshakes.length;
  const totalHoursCommitted = activeHandshakes.reduce(
    (sum, h) => sum + h.capacity_hours_per_month,
    0
  );

  const checkAlignment = (contact: Contact): { isAligned: boolean; matchingInterests: string[] } => {
    if (!contact.support_type || !advisor.interests) {
      return { isAligned: false, matchingInterests: [] };
    }
    
    const matchingInterests = contact.support_type.filter(type => 
      advisor.interests.includes(type)
    );
    
    return {
      isAligned: matchingInterests.length > 0,
      matchingInterests
    };
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">New Opportunities</h1>
        <p className="text-gray-600">
          Here you can see trusted companies in the Ethiq database that would like to connect with you about Advisory opportunities
        </p>
      </div>

      {/* Advisor Workload Summary */}
      <Card className="mb-6 bg-blue-50 border-blue-200">
        <div className="flex items-center gap-3 mb-3">
          <Activity className="w-5 h-5 text-[#163BB5]" />
          <h3 className="text-gray-900 font-semibold">Your Current Commitments</h3>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-gray-600 text-sm">Active Advisory Relationships</p>
            <p className="text-2xl font-semibold text-gray-900">{totalCommitments}</p>
          </div>
          <div>
            <p className="text-gray-600 text-sm">Total Hours/Month Committed</p>
            <p className="text-2xl font-semibold text-gray-900">{totalHoursCommitted}h</p>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('new')}
            className={`pb-3 border-b-2 transition-colors font-medium ${
              activeTab === 'new'
                ? 'border-[#163BB5] text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            New ({newContacts.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`pb-3 border-b-2 transition-colors font-medium ${
              activeTab === 'history'
                ? 'border-[#163BB5] text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            History ({historyContacts.length})
          </button>
        </div>
      </div>

      {/* Contacts list */}
      {currentList.length > 0 ? (
        <div className="space-y-6">
          {currentList.map((contact) => {
            const company = mockCompanies.find(c => c.id === contact.company_id);
            const date = new Date(contact.created_at).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
            });
            const alignment = checkAlignment(contact);
            
            // Calculate company engagement metrics
            const responseRate = company 
              ? Math.round((company.total_nudges_answered / company.total_nudges_sent) * 100)
              : 0;

            return (
              <Card key={contact.id} className="hover:border-gray-400 transition-all">
                {/* Header with Company Info */}
                <div className="flex items-start gap-5 mb-6 pb-6 border-b border-gray-200">
                  <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-[#163BB5] to-[#0D2A7A] flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-gray-900 font-semibold">
                        {company?.name || 'Company Name'}
                      </h3>
                      {contact.status !== 'Sent' && <StatusBadge status={contact.status} />}
                    </div>
                    <p className="text-gray-600 text-sm mb-2">
                      {company?.tagline || 'Company tagline'}
                    </p>
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="inline-block px-2.5 py-1 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                        {company?.stage || 'Stage'}
                      </span>
                      <span className="inline-block px-2.5 py-1 bg-purple-100 text-purple-700 rounded text-xs font-medium">
                        {company?.industry || 'Industry'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Company Activity & Engagement Stats */}
                <div className="mb-6 p-4 bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp className="w-5 h-5 text-[#163BB5]" />
                    <h4 className="font-semibold text-gray-900">Company Activity Overview</h4>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    {/* Advisor Count */}
                    <div className="flex items-start gap-3">
                      <Users className="w-5 h-5 text-[#163BB5] mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-gray-600 text-xs mb-1">Current Advisors</p>
                        <p className="text-xl font-bold text-gray-900">{company?.advisor_count || 0}</p>
                        <p className="text-gray-500 text-xs mt-0.5">
                          {company && company.advisor_count > 3 ? 'Well-established board' : 'Growing advisory team'}
                        </p>
                      </div>
                    </div>

                    {/* Nudge Activity */}
                    <div className="flex items-start gap-3">
                      <Zap className="w-5 h-5 text-[#163BB5] mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-gray-600 text-xs mb-1">Nudges Sent vs Answered</p>
                        <p className="text-xl font-bold text-gray-900">
                          {company?.total_nudges_sent || 0} / {company?.total_nudges_answered || 0}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-[#163BB5] rounded-full transition-all"
                              style={{ width: `${responseRate}%` }}
                            />
                          </div>
                          <span className="text-xs font-medium text-gray-700">{responseRate}%</span>
                        </div>
                      </div>
                    </div>

                    {/* Engagement Quality */}
                    <div className="flex items-start gap-3">
                      <Activity className="w-5 h-5 text-[#163BB5] mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-gray-600 text-xs mb-1">Engagement Quality</p>
                        <p className="text-xl font-bold text-gray-900">
                          {responseRate >= 70 ? 'High' : responseRate >= 40 ? 'Medium' : 'Low'}
                        </p>
                        <p className="text-gray-500 text-xs mt-0.5">
                          {responseRate >= 70 
                            ? 'Advisors actively engaged' 
                            : responseRate >= 40 
                            ? 'Moderate activity level'
                            : 'Building engagement'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Typical Nudge Types */}
                  {company?.typical_nudge_types && company.typical_nudge_types.length > 0 && (
                    <div>
                      <p className="text-gray-700 text-xs font-semibold mb-2">
                        Types of work they typically request:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {company.typical_nudge_types.map((type, index) => (
                          <span
                            key={index}
                            className="inline-block px-2.5 py-1 bg-white border border-gray-300 text-gray-700 rounded text-xs"
                          >
                            {type}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Key Details Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  {/* Sent Date */}
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4 text-[#163BB5]" />
                      <p className="text-gray-700 text-sm font-semibold">Sent Date</p>
                    </div>
                    <p className="text-gray-900 text-sm ml-6">{date}</p>
                  </div>

                  {/* Compensation */}
                  {contact.compensation && (
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <DollarSign className="w-4 h-4 text-[#163BB5]" />
                        <p className="text-gray-700 text-sm font-semibold">Compensation Offered</p>
                      </div>
                      <p className="text-gray-900 text-sm ml-6">{contact.compensation}</p>
                    </div>
                  )}
                </div>

                {/* Support Type & Alignment */}
                {contact.support_type && contact.support_type.length > 0 && (
                  <div className="mb-6">
                    <p className="text-gray-700 text-sm font-semibold mb-3">Type of Support Requested</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {contact.support_type.map((type, index) => (
                        <span
                          key={index}
                          className="inline-block px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg text-sm"
                        >
                          {type}
                        </span>
                      ))}
                    </div>
                    
                    {/* Alignment Indicator */}
                    <div className={`flex items-start gap-3 p-4 rounded-lg ${
                      alignment.isAligned 
                        ? 'bg-green-50 border border-green-200' 
                        : 'bg-amber-50 border border-amber-200'
                    }`}>
                      {alignment.isAligned ? (
                        <>
                          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-green-800 text-sm font-medium">
                              ✓ Aligned with your contribution preferences
                            </p>
                            <p className="text-green-700 text-xs mt-1">
                              Matches: {alignment.matchingInterests.join(', ')}
                            </p>
                          </div>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-amber-800 text-sm font-medium">
                              Does not match your "How I like to contribute" preferences
                            </p>
                            <p className="text-amber-700 text-xs mt-1">
                              Your preferences: {advisor.interests.join(', ')}
                            </p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}

                {/* Message */}
                <div className="mb-6">
                  <p className="text-gray-700 text-sm font-semibold mb-2">Message from Company</p>
                  <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <p className="text-gray-700 text-sm leading-relaxed">{contact.message}</p>
                  </div>
                </div>

                {/* Workload Impact */}
                {contact.status === 'Sent' && (
                  <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm font-semibold text-gray-900 mb-2">
                      💡 Consider Before Accepting
                    </p>
                    <ul className="space-y-1.5 text-sm text-gray-700">
                      <li>• You currently have <span className="font-semibold">{totalCommitments} active advisory relationships</span></li>
                      <li>• Your total commitment is <span className="font-semibold">{totalHoursCommitted} hours/month</span></li>
                      <li>• This company has <span className="font-semibold">{company?.advisor_count || 0} advisors</span> and sends an average of <span className="font-semibold">{company ? Math.round(company.total_nudges_sent / company.advisor_count) : 0} nudges per advisor</span></li>
                      <li>• Their response rate is <span className="font-semibold">{responseRate}%</span> ({responseRate >= 70 ? 'highly engaged' : responseRate >= 40 ? 'moderately engaged' : 'still building engagement'})</li>
                    </ul>
                  </div>
                )}

                {/* Action buttons for new contacts */}
                {contact.status === 'Sent' && (
                  <div className="flex gap-3 pt-4 border-t border-gray-200">
                    <Button 
                      onClick={() => onAccept(contact.id)}
                      className="flex-1"
                    >
                      Accept Opportunity
                    </Button>
                    <Button 
                      variant="destructive" 
                      onClick={() => onDecline(contact.id)}
                      className="flex-1"
                    >
                      Decline
                    </Button>
                  </div>
                )}

                {/* Responded date for history */}
                {contact.responded_at && (
                  <div className="pt-4 border-t border-gray-200">
                    <p className="text-gray-600 text-sm">
                      Responded on {new Date(contact.responded_at).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </p>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-8 h-8 text-gray-400" />
            </div>
            <h2 className="text-gray-900 mb-2 font-semibold">
              No {activeTab === 'new' ? 'new' : ''} opportunities
            </h2>
            <p className="text-gray-600">
              {activeTab === 'new'
                ? 'No pending connection requests at this time'
                : 'No contact history yet'}
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
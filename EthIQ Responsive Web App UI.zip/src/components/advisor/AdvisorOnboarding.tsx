import { useState } from 'react';
import { Card } from '../ui/Card';
import { MultiSelectDropdown } from '../ui/MultiSelectDropdown';
import { Button } from '../ui/Button';
import { X } from 'lucide-react';
import { Logo } from '../ui/Logo';

interface AdvisorOnboardingProps {
  onComplete: (profile: {
    email: string;
    name: string;
    bio: string;
    open_to_new_advisory_boards: boolean;
    special_domains: string[];
    interests: string[];
    executive_type: string;
  }) => void;
}

const predefinedTags = [
  'Human Resources',
  'Health',
  'Finance',
  'Founding Team',
  'VC / PE',
  'Talent',
  'Climate',
  'Author, Columnist, Writer',
  'Tech, Product',
  'M&A',
  'Non-Profit',
];

const interestOptions = [
  'Thought Leadership (Speaking, Writing, Etc)',
  'Networking & Peer Connections',
  'Volunteer & Non-Profit',
  'Fundraising',
  'Business Planning & Strategy',
];

const advisorTypeOptions = [
  'Current Executive - Public Company',
  'Former Executive - Public Company',
  'Current Executive - Private Company',
  'Former Executive - Private Company',
  'Founder or CEO',
  'Consultant',
  'Venture Capitalist',
];

export function AdvisorOnboarding({ onComplete }: AdvisorOnboardingProps) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [openToNewBoards, setOpenToNewBoards] = useState(true);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [customTag, setCustomTag] = useState('');
  const [selectedInterest, setSelectedInterest] = useState<string>('');
  const [advisorType, setAdvisorType] = useState('');
  const [errors, setErrors] = useState<{ 
    email?: string; 
    name?: string; 
    interest?: string; 
    advisorType?: string;
  }>({});

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const addCustomTag = () => {
    if (customTag.trim() && !selectedTags.includes(customTag.trim())) {
      setSelectedTags((prev) => [...prev, customTag.trim()]);
      setCustomTag('');
    }
  };

  const removeTag = (tag: string) => {
    setSelectedTags((prev) => prev.filter((t) => t !== tag));
  };

  const toggleInterest = (interest: string) => {
    setSelectedInterest(interest);
    if (errors.interest) {
      setErrors((prev) => ({ ...prev, interest: undefined }));
    }
  };

  const handleAdvisorTypeChange = (type: string) => {
    setAdvisorType(type);
    if (errors.advisorType) {
      setErrors((prev) => ({ ...prev, advisorType: undefined }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newErrors: { 
      email?: string; 
      name?: string; 
      interest?: string; 
      advisorType?: string;
    } = {};

    // Validate email (required field)
    if (!email.trim()) {
      newErrors.email = 'Please enter your email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Validate name (required field)
    if (!name.trim()) {
      newErrors.name = 'Please enter your name';
    }

    // Validate interests (required field)
    if (!selectedInterest) {
      newErrors.interest = 'Please select at least one interest';
    }

    // Validate advisor type (required field)
    if (!advisorType) {
      newErrors.advisorType = 'Please select your advisor type';
    }

    // If there are errors, set them and don't submit
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Save the profile
    onComplete({
      email,
      name,
      bio,
      open_to_new_advisory_boards: openToNewBoards,
      special_domains: selectedTags,
      interests: [selectedInterest],
      executive_type: advisorType,
    });
  };

  return (
    <div className="min-h-screen bg-[#F9F9F9]">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-center">
          <div className="flex items-center">
            <Logo className="h-10 w-auto" />
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Create Your Advisor Profile</h1>
          <p className="text-gray-600">Join the Ethiq community and start connecting with companies</p>
        </div>

        <form onSubmit={handleSubmit}>
          <Card className="mb-6">
            {/* Email */}
            <div className="mb-6">
              <label className="block text-gray-900 mb-2">
                Email Address <span className="text-red-600">*</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) {
                    setErrors((prev) => ({ ...prev, email: undefined }));
                  }
                }}
                placeholder="your.email@example.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent"
              />
              {errors.email && (
                <p className="text-red-600 mt-2">{errors.email}</p>
              )}
            </div>

            {/* Name */}
            <div className="mb-6">
              <label className="block text-gray-900 mb-2">
                Full Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (errors.name) {
                    setErrors((prev) => ({ ...prev, name: undefined }));
                  }
                }}
                placeholder="Enter your full name..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent"
              />
              {errors.name && (
                <p className="text-red-600 mt-2">{errors.name}</p>
              )}
            </div>

            {/* Advisor Type Dropdown */}
            <div className="mb-6">
              <label className="block text-gray-900 mb-2">
                Please select your advisor type <span className="text-red-600">*</span>
              </label>
              <p className="text-gray-600 mb-2">Select one option</p>
              <select
                value={advisorType}
                onChange={(e) => handleAdvisorTypeChange(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent bg-white"
              >
                <option value="">Select advisor type...</option>
                {advisorTypeOptions.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              {errors.advisorType && (
                <p className="text-red-600 mt-2">{errors.advisorType}</p>
              )}
            </div>

            {/* Interest Dropdown */}
            <div className="mb-6 pb-6 border-b border-gray-200">
              <label className="block text-gray-900 mb-2">
                Please add how you like to support companies <span className="text-red-600">*</span>
              </label>
              <p className="text-gray-600 mb-2">Select at least one option</p>
              <select
                value={selectedInterest}
                onChange={(e) => toggleInterest(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent bg-white"
              >
                <option value="">Select how you like to support...</option>
                {interestOptions.map((interest) => (
                  <option key={interest} value={interest}>
                    {interest}
                  </option>
                ))}
              </select>
              {errors.interest && (
                <p className="text-red-600 mt-2">{errors.interest}</p>
              )}
            </div>

            {/* Bio */}
            <div className="mb-6 pb-6 border-b border-gray-200">
              <label className="block text-gray-900 mb-2">
                Tell us about your experience and background in a few sentences
              </label>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Share your background, expertise, and what you're passionate about..."
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent resize-none"
              />
            </div>

            {/* Open to new boards */}
            <div className="mb-6 pb-6 border-b border-gray-200">
              <label className="flex items-center gap-3 cursor-pointer">
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={openToNewBoards}
                    onChange={(e) => setOpenToNewBoards(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-300 rounded-full peer-checked:bg-[#163BB5] transition-colors"></div>
                  <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-5"></div>
                </div>
                <div>
                  <p className="text-gray-900">Are you open to new Advisory Board positions?</p>
                  <p className="text-gray-600">
                    {openToNewBoards
                      ? 'You will be visible in the company directory'
                      : 'You will be hidden from the company directory'}
                  </p>
                </div>
              </label>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-gray-900 mb-2">
                Would you like to add tags you identify with?
              </label>
              <p className="text-gray-600 mb-4">
                Select tags that describe your expertise and background
              </p>

              <div className="flex flex-wrap gap-2 mb-4">
                {predefinedTags.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`px-3 py-1 rounded-full border transition-all ${
                      selectedTags.includes(tag)
                        ? 'bg-[#163BB5] text-white border-[#163BB5]'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>

              {/* Custom tags */}
              <div className="flex gap-2 mb-4">
                <input
                  type="text"
                  value={customTag}
                  onChange={(e) => setCustomTag(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addCustomTag();
                    }
                  }}
                  placeholder="Add custom tag..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent"
                />
                <Button type="button" onClick={addCustomTag}>
                  Add
                </Button>
              </div>

              {/* Selected tags that aren't in predefined list */}
              {selectedTags.filter((tag) => !predefinedTags.includes(tag)).length > 0 && (
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-gray-700 mb-2">Custom tags:</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedTags
                      .filter((tag) => !predefinedTags.includes(tag))
                      .map((tag) => (
                        <span
                          key={tag}
                          className="inline-flex items-center gap-1 px-3 py-1 bg-[#163BB5] text-white rounded-full"
                        >
                          {tag}
                          <button
                            type="button"
                            onClick={() => removeTag(tag)}
                            className="hover:bg-white/20 rounded-full p-0.5"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* Action buttons */}
          <div className="flex gap-3">
            <Button type="submit">Create Profile</Button>
          </div>
        </form>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { Card } from '../ui/Card';
import { Building2, Calendar, Zap, Search, Clock, MessageCircle, CheckCircle2 } from 'lucide-react';
import { Handshake, mockCompanies, mockNudges } from '../../data/mockData';

interface AdvisorCompaniesProps {
  handshakes: Handshake[];
}

export function AdvisorCompanies({ handshakes }: AdvisorCompaniesProps) {
  const [searchTerm, setSearchTerm] = useState('');

  // Get unique companies with active handshakes
  const activeHandshakes = handshakes.filter((h) => h.status === 'Active');
  
  // Group handshakes by company and get company info
  const companies = activeHandshakes.reduce((acc, handshake) => {
    const companyData = mockCompanies.find(c => c.id === handshake.company_id);
    if (!companyData) return acc;

    const existing = acc.find(c => c.id === companyData.id);
    if (existing) {
      existing.handshakes.push(handshake);
    } else {
      acc.push({
        ...companyData,
        handshakes: [handshake],
      });
    }
    return acc;
  }, [] as Array<typeof mockCompanies[0] & { handshakes: Handshake[] }>);

  // Filter by search
  const filteredCompanies = companies.filter((company) =>
    company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.industry.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRelationshipDuration = (startedAt: string) => {
    const started = new Date(startedAt);
    const now = new Date();
    const months = Math.floor(
      (now.getTime() - started.getTime()) / (1000 * 60 * 60 * 24 * 30)
    );
    if (months < 1) return 'New relationship';
    if (months === 1) return '1 month';
    return `${months} months`;
  };

  const getTotalNudges = (companyId: string) => {
    return mockNudges.filter(n => n.company_id === companyId).length;
  };

  const getCompletedNudges = (companyId: string) => {
    return mockNudges.filter(n => n.company_id === companyId && n.status === 'Completed').length;
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Company Relationships</h1>
        <p className="text-gray-600">View all companies you have active advisory relationships with</p>
      </div>

      {/* Search */}
      <Card className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search companies by name or industry..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#163BB5] focus:border-transparent"
          />
        </div>
      </Card>

      {/* Results count */}
      <p className="text-gray-600 mb-6 text-sm">
        {filteredCompanies.length} active relationship{filteredCompanies.length !== 1 ? 's' : ''}
      </p>

      {/* Companies grid */}
      {filteredCompanies.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCompanies.map((company) => {
            const oldestHandshake = company.handshakes.sort((a, b) => 
              new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
            )[0];
            const totalNudges = getTotalNudges(company.id);
            const completedNudges = getCompletedNudges(company.id);
            const totalHoursPerMonth = company.handshakes.reduce((sum, h) => sum + h.capacity_hours_per_month, 0);

            return (
              <Card key={company.id} className="hover:border-gray-400 hover:shadow-md transition-all">
                {/* Company Header */}
                <div className="flex items-start gap-4 mb-6 pb-6 border-b border-gray-200">
                  <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-[#163BB5] to-[#0D2A7A] flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-gray-900 mb-1.5 font-semibold">{company.name}</h3>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="inline-block px-2 py-0.5 bg-green-100 text-green-700 rounded text-xs font-medium">
                        Active
                      </span>
                      <span className="inline-block px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                        {company.stage}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Company Info */}
                <div className="mb-6">
                  <p className="text-gray-700 text-sm font-semibold mb-2">Industry</p>
                  <p className="text-gray-600 text-sm">{company.industry}</p>
                </div>

                {/* Active Handshakes */}
                <div className="mb-6">
                  <p className="text-gray-700 text-sm font-semibold mb-3">Active Engagements ({company.handshakes.length})</p>
                  <div className="space-y-2">
                    {company.handshakes.map((handshake) => (
                      <div key={handshake.id} className="bg-gray-50 rounded-lg p-3">
                        <p className="text-gray-900 text-sm font-medium mb-1">{handshake.title}</p>
                        <div className="flex items-center gap-2 text-xs text-gray-600">
                          <span className="px-2 py-0.5 bg-white rounded border border-gray-200">
                            {handshake.engagement_style}
                          </span>
                          <span>•</span>
                          <span>{handshake.capacity_hours_per_month}h/month</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stats */}
                <div className="border-t border-gray-200 pt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-gray-600 text-sm">
                      <Calendar className="w-4 h-4 text-[#163BB5]" />
                      <span>Relationship</span>
                    </div>
                    <span className="text-gray-900 text-sm font-medium">
                      {getRelationshipDuration(oldestHandshake.created_at)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-gray-600 text-sm">
                      <MessageCircle className="w-4 h-4 text-[#163BB5]" />
                      <span>Nudges</span>
                    </div>
                    <span className="text-gray-900 text-sm font-medium">
                      {totalNudges} total
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-gray-600 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      <span>Completed</span>
                    </div>
                    <span className="text-gray-900 text-sm font-medium">
                      {completedNudges} of {totalNudges}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-gray-600 text-sm">
                      <Clock className="w-4 h-4 text-[#163BB5]" />
                      <span>Capacity</span>
                    </div>
                    <span className="text-gray-900 text-sm font-medium">
                      {totalHoursPerMonth}h/month
                    </span>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-gray-900 mb-2">No companies found</h3>
            <p className="text-gray-600">
              {searchTerm
                ? 'Try adjusting your search terms'
                : 'You don\'t have any active advisory relationships yet'}
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
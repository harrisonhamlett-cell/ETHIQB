import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { User, Handshake, BarChart3, Mail, Briefcase, CheckCircle, XCircle, Camera } from 'lucide-react';
import { Nudge, Advisor } from '../../data/mockData';

interface AdvisorHomeProps {
  nudges: Nudge[];
  advisor: Advisor;
  onNavigate: (page: string) => void;
}

export function AdvisorHome({ nudges, advisor, onNavigate }: AdvisorHomeProps) {
  // Get most recent nudges sorted by created_at
  const recentNudges = [...nudges].sort((a, b) => 
    new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  const handleAvatarClick = () => {
    // In a real app, this would trigger a file upload dialog
    alert('Click to upload a profile photo. This would open a file picker in a real implementation.');
  };

  return (
    <div>
      {/* Profile Overview */}
      <Card className="mb-8 bg-gradient-to-br from-blue-50 via-slate-50 to-blue-50 border-[#163BB5]/20 shadow-md">
        <div className="flex items-start justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-4 mb-6">
              {/* Avatar - Clickable to upload photo */}
              <button
                onClick={handleAvatarClick}
                className="relative w-20 h-20 rounded-full group cursor-pointer flex-shrink-0"
                title="Click to upload profile photo"
              >
                {advisor.profile_photo_url ? (
                  <img 
                    src={advisor.profile_photo_url} 
                    alt={advisor.name}
                    className="w-full h-full rounded-full object-cover border-2 border-[#163BB5]/20 group-hover:border-[#163BB5] transition-all"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-[#163BB5] to-[#0D2A7A] rounded-full flex items-center justify-center border-2 border-[#163BB5]/20 group-hover:scale-105 transition-all">
                    <User className="w-10 h-10 text-white" />
                  </div>
                )}
                {/* Camera overlay on hover */}
                <div className="absolute inset-0 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Camera className="w-6 h-6 text-white" />
                </div>
              </button>

              <div>
                <h1 className="text-gray-900 mb-1.5">{advisor.name}</h1>
                <p className="text-gray-700 text-sm font-medium">{advisor.role}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
              <div className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#163BB5] mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-700 text-sm font-semibold mb-1">Email</p>
                  <p className="text-gray-600 text-sm">{advisor.email}</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Briefcase className="w-4 h-4 text-[#163BB5] mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-700 text-sm font-semibold mb-1">Executive Type</p>
                  <p className="text-gray-600 text-sm">{advisor.executive_type}</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                {advisor.open_to_new_advisory_boards ? (
                  <CheckCircle className="w-4 h-4 text-green-600 mt-1 flex-shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
                )}
                <div>
                  <p className="text-gray-700 text-sm font-semibold mb-1">Visibility Status</p>
                  <p className={`text-sm font-medium ${advisor.open_to_new_advisory_boards ? 'text-green-700' : 'text-gray-600'}`}>
                    {advisor.open_to_new_advisory_boards 
                      ? 'Open to new opportunities' 
                      : 'Not accepting new opportunities'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <User className="w-4 h-4 text-[#163BB5] mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-700 text-sm font-semibold mb-1">Experience</p>
                  <p className="text-gray-600 text-sm font-medium">{advisor.years_experience} years</p>
                </div>
              </div>
            </div>

            {advisor.special_domains && advisor.special_domains.length > 0 && (
              <div className="mb-5">
                <p className="text-gray-700 text-sm font-semibold mb-2.5">Expertise</p>
                <div className="flex flex-wrap gap-2">
                  {advisor.special_domains.slice(0, 5).map((domain) => (
                    <span 
                      key={domain}
                      className="px-3 py-1.5 bg-[#163BB5]/10 text-[#163BB5] text-sm font-medium rounded-md"
                    >
                      {domain}
                    </span>
                  ))}
                  {advisor.special_domains.length > 5 && (
                    <span className="px-3 py-1.5 bg-gray-200 text-gray-700 text-sm font-medium rounded-md">
                      +{advisor.special_domains.length - 5} more
                    </span>
                  )}
                </div>
              </div>
            )}

            {advisor.bio && (
              <div>
                <p className="text-gray-700 text-sm font-semibold mb-2">Bio</p>
                <p className="text-gray-700 text-sm line-clamp-2 leading-relaxed">{advisor.bio}</p>
              </div>
            )}
          </div>

          <div className="flex-shrink-0">
            <Button onClick={() => onNavigate('profile-edit')}>
              Update Profile & Visibility
            </Button>
          </div>
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="mb-12">
        <h2 className="text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button
            onClick={() => onNavigate('profile-edit')}
            className="group"
          >
            <Card className="h-full hover:border-gray-400 hover:shadow-md transition-all text-left">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#163BB5] to-[#0D2A7A] rounded-full flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <User className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-gray-900 mb-2">View my Advisor Profile</h3>
                <p className="text-gray-600 text-sm">Update your profile, bio, and visibility settings</p>
              </div>
            </Card>
          </button>

          <button
            onClick={() => onNavigate('contacts')}
            className="group"
          >
            <Card className="h-full hover:border-gray-400 hover:shadow-md transition-all text-left">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#163BB5] to-[#0D2A7A] rounded-full flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Handshake className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-gray-900 mb-2">Connect with New Opportunities</h3>
                <p className="text-gray-600 text-sm">Review and respond to incoming connection requests</p>
              </div>
            </Card>
          </button>

          <button
            onClick={() => onNavigate('engagement')}
            className="group"
          >
            <Card className="h-full hover:border-gray-400 hover:shadow-md transition-all text-left">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#163BB5] to-[#0D2A7A] rounded-full flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-gray-900 mb-2">See my Engagement</h3>
                <p className="text-gray-600 text-sm">View your activity, insights, and performance metrics</p>
              </div>
            </Card>
          </button>
        </div>
      </div>

      {/* Recent nudges */}
      {recentNudges.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-gray-900">Recent Nudges</h2>
            <button
              onClick={() => onNavigate('nudges')}
              className="text-[#163BB5] hover:text-[#0D2A7A] transition-colors text-sm"
            >
              See more →
            </button>
          </div>

          <div className="space-y-3">
            {recentNudges.slice(0, 3).map((nudge) => {
              const date = new Date(nudge.created_at).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
              });

              return (
                <Card 
                  key={nudge.id} 
                  className="hover:border-gray-300 transition-colors cursor-pointer"
                  onClick={() => onNavigate('nudges')}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="inline-block px-2 py-1 bg-yellow-200 text-gray-900 rounded text-xs whitespace-nowrap">
                          {nudge.nudge_tag}
                        </span>
                        <span className="text-gray-500 text-xs">{date}</span>
                      </div>
                      <p className="text-gray-900 text-sm line-clamp-2 mb-1">
                        {nudge.details}
                      </p>
                      <p className="text-gray-500 text-xs">
                        Est. time: {nudge.max_time_requested}
                      </p>
                    </div>
                    <div className="flex-shrink-0">
                      {nudge.status === 'Sent' && (
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                          New
                        </span>
                      )}
                      {nudge.status === 'Accepted' && !nudge.advisor_completed && (
                        <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">
                          In Progress
                        </span>
                      )}
                      {nudge.status === 'Completed' && (
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                          Completed
                        </span>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { Tabs } from '../ui/Tabs';
import { EmptyState } from '../ui/EmptyState';
import { Inbox, CheckCircle2, Clock, Filter } from 'lucide-react';
import { Nudge } from '../../data/mockData';
import { MultiSelectDropdown } from '../ui/MultiSelectDropdown';

interface AdvisorNudgesProps {
  nudges: Nudge[];
  onAccept: (nudgeId: string) => void;
  onDecline: (nudgeId: string) => void;
  onMarkComplete: (nudgeId: string) => void;
}

export function AdvisorNudges({ nudges, onAccept, onDecline, onMarkComplete }: AdvisorNudgesProps) {
  const [activeTab, setActiveTab] = useState(0);
  const [nudgeTypeFilters, setNudgeTypeFilters] = useState<string[]>([]);
  const [timeCommitmentFilter, setTimeCommitmentFilter] = useState('');

  const nudgeTypes = [
    'Feedback Request',
    'Meeting',
    'Introduction Request',
    'Event Attendance',
    'Thought Leadership',
    'Other',
  ];

  // Apply filters before status filtering
  const filteredNudges = nudges.filter((nudge) => {
    const matchesNudgeType =
      nudgeTypeFilters.length === 0 || nudgeTypeFilters.includes(nudge.nudge_tag);

    const matchesTimeCommitment =
      timeCommitmentFilter === '' || nudge.max_time_requested === timeCommitmentFilter;

    return matchesNudgeType && matchesTimeCommitment;
  });

  const newNudges = filteredNudges.filter((n) => n.status === 'Sent');
  const inProgressNudges = filteredNudges.filter(
    (n) => n.status === 'Accepted' && !n.advisor_completed
  );
  const awaitingConfirmation = filteredNudges.filter(
    (n) => n.advisor_completed && !n.company_confirmed
  );
  const historyNudges = filteredNudges.filter(
    (n) => n.status === 'Declined' || n.status === 'Completed'
  );

  // Get unique time commitments from nudges
  const uniqueTimeCommitments = [...new Set(nudges.map((n) => n.max_time_requested))].sort();

  const tabs = [
    { label: 'New', count: newNudges.length },
    { label: 'In Progress', count: inProgressNudges.length },
    { label: 'History', count: historyNudges.length },
  ];

  const renderNudgeList = (
    nudgeList: Nudge[],
    showAcceptDecline = false,
    showMarkComplete = false
  ) => {
    if (nudgeList.length === 0) {
      return (
        <EmptyState
          icon={<Inbox className="w-12 h-12" />}
          title="No nudges here"
          description="Nudges matching this status will appear here."
        />
      );
    }

    return (
      <div className="space-y-4">
        {nudgeList.map((nudge) => {
          const date = new Date(nudge.created_at).toLocaleDateString('en-US', {
            month: '2-digit',
            day: '2-digit',
            year: 'numeric',
          });
          const time = new Date(nudge.created_at).toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true,
          });

          const isAwaitingConfirmation = nudge.advisor_completed && !nudge.company_confirmed;
          const isCompleted = nudge.status === 'Completed';

          return (
            <Card key={nudge.id}>
              {/* Header */}
              <div className="mb-4">
                <p className="text-gray-600 mb-2">Nudge</p>
                <div className="inline-block px-3 py-1 bg-yellow-200 text-gray-900 rounded-md mb-3">
                  {nudge.nudge_tag}
                </div>
              </div>

              {/* Details section */}
              <div className="space-y-3 mb-4">
                <div>
                  <p className="text-gray-700">Details:</p>
                  <p className="text-gray-600">{nudge.details}</p>
                </div>

                <div>
                  <p className="text-gray-700">Company Requested:</p>
                  <p className="text-gray-600">{date}, {time}</p>
                </div>

                <div>
                  <p className="text-gray-700">Max hours to complete:</p>
                  <p className="text-gray-600">{nudge.max_time_requested}</p>
                </div>
              </div>

              {/* Status badge */}
              {nudge.status !== 'Sent' && (
                <div className="mb-4">
                  <StatusBadge status={nudge.status} />
                </div>
              )}

              {/* Show awaiting confirmation status */}
              {isAwaitingConfirmation && !isCompleted && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 flex items-start gap-3 mb-4">
                  <Clock className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-orange-900">
                      <strong>Awaiting company confirmation</strong>
                    </p>
                    <p className="text-orange-700">
                      You've marked this as complete. Waiting for the company to confirm.
                    </p>
                  </div>
                </div>
              )}

              {/* Show completed checkmarks */}
              {isCompleted && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                  <div className="flex gap-6 text-green-900">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Advisor completed</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Company confirmed</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Action buttons */}
              {showAcceptDecline && (
                <div className="flex gap-3">
                  <Button onClick={() => onAccept(nudge.id)} size="sm">
                    Accept
                  </Button>
                  <Button onClick={() => onDecline(nudge.id)} variant="destructive" size="sm">
                    Decline
                  </Button>
                </div>
              )}

              {showMarkComplete && !nudge.advisor_completed && (
                <div>
                  <Button onClick={() => onMarkComplete(nudge.id)} size="sm">
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Mark complete
                  </Button>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    );
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 0:
        return renderNudgeList(newNudges, true, false);
      case 1:
        // Combine in-progress and awaiting confirmation
        const allInProgress = [...inProgressNudges, ...awaitingConfirmation].sort(
          (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
        );
        return renderNudgeList(
          allInProgress,
          false,
          // Only show "Mark complete" if advisor hasn't completed yet
          true
        );
      case 2:
        return renderNudgeList(historyNudges);
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Nudges</h1>
        <p className="text-gray-600">Manage your nudge requests and responses</p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <p className="text-blue-900">
          <strong>Completion workflow:</strong> When you mark a nudge as complete, the company must
          confirm completion to finalize. Completed requires both you and the company to acknowledge
          completion.
        </p>
      </div>

      {/* Filters Section */}
      <div className="bg-gradient-to-br from-gray-100 to-gray-200 border-2 border-gray-400 rounded-xl p-6 mb-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Filter className="w-5 h-5 text-gray-700" />
            <div>
              <h2 className="text-gray-900 mb-1">Filter Nudges</h2>
              <p className="text-gray-600 text-sm">Narrow down nudges by type and time commitment</p>
            </div>
          </div>
          {(nudgeTypeFilters.length > 0 || timeCommitmentFilter !== '') && (
            <button
              onClick={() => {
                setNudgeTypeFilters([]);
                setTimeCommitmentFilter('');
              }}
              className="text-gray-700 hover:text-gray-900 transition-colors text-sm"
            >
              Clear all filters
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <MultiSelectDropdown
            label="Nudge Type"
            options={nudgeTypes}
            selected={nudgeTypeFilters}
            onChange={setNudgeTypeFilters}
            placeholder="All types"
          />

          <div>
            <label className="block text-gray-700 mb-2 uppercase text-xs">
              Time Commitment
            </label>
            <select
              value={timeCommitmentFilter}
              onChange={(e) => setTimeCommitmentFilter(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent bg-white"
            >
              <option value="">All commitments</option>
              {uniqueTimeCommitments.map((time) => (
                <option key={time} value={time}>
                  {time}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <Card>
        <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />
        <div className="mt-6">{renderTabContent()}</div>
      </Card>
    </div>
  );
}
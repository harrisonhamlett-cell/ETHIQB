import { useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Handshake } from '../../data/mockData';
import { StatusBadge } from '../ui/StatusBadge';

interface AdvisorHandshakesProps {
  handshakes: Handshake[];
  onAccept: (handshakeId: string) => void;
  onDismiss: (handshakeId: string) => void;
}

export function AdvisorHandshakes({ handshakes, onAccept, onDismiss }: AdvisorHandshakesProps) {
  const [activeTab, setActiveTab] = useState<'proposed' | 'active' | 'history'>('proposed');

  const proposedHandshakes = handshakes.filter((h) => h.status === 'Proposed');
  const activeHandshakes = handshakes.filter((h) => h.status === 'Active');
  const historyHandshakes = handshakes.filter(
    (h) => h.status === 'Dismissed' || h.status === 'Paused' || h.status === 'Ended'
  );

  const currentList =
    activeTab === 'proposed'
      ? proposedHandshakes
      : activeTab === 'active'
      ? activeHandshakes
      : historyHandshakes;

  const getCompanyName = () => 'Ethiq Company'; // In real app, fetch from company_id

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Handshakes</h1>
        <p className="text-gray-600">
          Handshakes define how you work together (capacity, cadence, and expectations)
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('proposed')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'proposed'
                ? 'border-gray-900 text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Proposed ({proposedHandshakes.length})
          </button>
          <button
            onClick={() => setActiveTab('active')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'active'
                ? 'border-gray-900 text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Active ({activeHandshakes.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`pb-3 border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-gray-900 text-gray-900'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            History ({historyHandshakes.length})
          </button>
        </div>
      </div>

      {/* Handshakes list */}
      {currentList.length > 0 ? (
        <div className="space-y-4">
          {currentList.map((handshake) => {
            const date = new Date(handshake.created_at).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
            });

            return (
              <Card key={handshake.id}>
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-gray-900">{getCompanyName()}</h3>
                    <StatusBadge status={handshake.status} />
                  </div>
                  {handshake.title && (
                    <p className="text-gray-600">{handshake.title}</p>
                  )}
                </div>

                <div className="space-y-2 text-gray-600 mb-4">
                  <p>
                    <strong className="text-gray-700">Capacity:</strong>{' '}
                    {handshake.capacity_hours_per_month} hours/month
                  </p>
                  <p>
                    <strong className="text-gray-700">Cadence:</strong>{' '}
                    {handshake.engagement_style}
                  </p>
                  <p>
                    <strong className="text-gray-700">Response expectation:</strong>{' '}
                    {handshake.response_expectation}
                  </p>
                  <p>
                    <strong className="text-gray-700">Channels:</strong>{' '}
                    {handshake.channels.join(', ')}
                  </p>
                  {handshake.focus_areas.length > 0 && (
                    <p>
                      <strong className="text-gray-700">Focus areas:</strong>{' '}
                      {handshake.focus_areas.join(', ')}
                    </p>
                  )}
                </div>

                {handshake.notes && (
                  <div className="bg-gray-50 rounded-lg p-3 mb-4">
                    <p className="text-gray-700">
                      <strong>Notes:</strong>
                    </p>
                    <p className="text-gray-600">{handshake.notes}</p>
                  </div>
                )}

                <p className="text-gray-600 mb-4">Proposed {date}</p>

                {handshake.status === 'Proposed' && (
                  <div className="flex gap-3 pt-4 border-t border-gray-200">
                    <Button onClick={() => onAccept(handshake.id)}>Accept</Button>
                    <Button variant="destructive" onClick={() => onDismiss(handshake.id)}>
                      Dismiss
                    </Button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="text-center py-12">
          <h2 className="text-gray-900 mb-2">
            No {activeTab} handshakes
          </h2>
          <p className="text-gray-600">
            {activeTab === 'proposed'
              ? 'No pending handshake proposals at this time'
              : activeTab === 'active'
              ? 'No active handshakes at this time'
              : 'No handshake history yet'}
          </p>
        </Card>
      )}
    </div>
  );
}
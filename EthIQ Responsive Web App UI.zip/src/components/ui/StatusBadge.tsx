interface StatusBadgeProps {
  status:
    | 'Sent'
    | 'Accepted'
    | 'Declined'
    | 'Proposed'
    | 'Active'
    | 'Dismissed'
    | 'Paused'
    | 'Ended'
    | 'Completed'
    | 'Expired'
    | 'Withdrawn';
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const styles: Record<typeof status, string> = {
    Sent: 'bg-blue-100 text-blue-700',
    Accepted: 'bg-green-100 text-green-700',
    Declined: 'bg-red-100 text-red-700',
    Proposed: 'bg-purple-100 text-purple-700',
    Active: 'bg-green-100 text-green-700',
    Dismissed: 'bg-gray-100 text-gray-700',
    Paused: 'bg-orange-100 text-orange-700',
    Ended: 'bg-gray-100 text-gray-700',
    Completed: 'bg-green-100 text-green-700',
    Expired: 'bg-gray-100 text-gray-700',
    Withdrawn: 'bg-gray-100 text-gray-700',
  };

  return (
    <span className={`inline-block px-2 py-1 rounded-md ${styles[status]}`}>
      {status}
    </span>
  );
}

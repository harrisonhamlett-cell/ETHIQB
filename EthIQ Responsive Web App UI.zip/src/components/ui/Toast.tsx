import { useEffect, useState } from 'react';
import { CheckCircle2, X } from 'lucide-react';

interface ToastProps {
  message: string;
  onClose: () => void;
}

export function Toast({ message, onClose }: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-6 right-6 z-50 bg-gray-900 text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-3 max-w-md">
      <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0" />
      <span>{message}</span>
      <button onClick={onClose} className="ml-2 hover:text-gray-300">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}

export function useToast() {
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToast(message);
  };

  const ToastComponent = () => {
    return toast ? <Toast message={toast} onClose={() => setToast(null)} /> : null;
  };

  return { showToast, ToastComponent };
}
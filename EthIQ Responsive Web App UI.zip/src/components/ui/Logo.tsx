interface LogoProps {
  className?: string;
  width?: number;
  height?: number;
}

/**
 * Ethiq Logo Component
 * 
 * TEMPORARY: Currently uses an SVG placeholder
 * TODO: Replace with actual logo once exported from Figma
 * 
 * To replace with PNG:
 * 1. Add logo file to /public/assets/ethiq-logo.png
 * 2. Uncomment the <img> version below
 * 3. Delete the <svg> version
 */
export function Logo({ className = '', width = 120, height = 40 }: LogoProps) {
  // VERSION 1: SVG Placeholder (current - works everywhere)
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 120 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Background */}
      <rect width="120" height="40" rx="6" fill="#163BB5" />
      
      {/* "Ethiq" text */}
      <text
        x="60"
        y="26"
        fontFamily="system-ui, -apple-system, sans-serif"
        fontSize="20"
        fontWeight="700"
        fill="white"
        textAnchor="middle"
      >
        Ethiq
      </text>
      
      {/* Accent dot */}
      <circle cx="102" cy="20" r="3" fill="#60A5FA" />
    </svg>
  );

  // VERSION 2: PNG Image (uncomment when you have the real logo)
  // return (
  //   <img
  //     src="/assets/ethiq-logo.png"
  //     alt="Ethiq"
  //     width={width}
  //     height={height}
  //     className={className}
  //   />
  // );
}
